/* 
 Sound Importing
 If you are curious to what's going on here, look at the lvm's code.
 */
// vars
const loadPost = require("../misc/post_body");
const formidable = require("formidable");
const asset = require("./main");
const http = require("http");
const fs = require("fs");

// creates meta folders for a subtype if they don't exist
function createMetaFolders(mode) {
  try {
    if (!fs.existsSync('./meta')) fs.mkdirSync('./meta');
    if (!fs.existsSync(`./meta/${mode}`)) fs.mkdirSync(`./meta/${mode}`);
    if (!fs.existsSync(`./meta/${mode}/titles`)) fs.mkdirSync(`./meta/${mode}/titles`);
    return true;
  } catch (e) {
    console.log(e);
  }
}

function createTypeFolders(type) {
        const folder = `./${type}`;
        try {
                if (!fs.existsSync(folder)) fs.mkdirSync(folder);
        } catch (e) {
                console.log(e);
        }
}

module.exports = function (req, res, url) {
	if (req.method != "POST") return;
	switch (url.pathname) {
		case "/goapi/saveSound/": {
                        new formidable.IncomingForm().parse(req, (e, f, files) => {
                                console.log(f, files);
                        });
                        return true;
                }
        }
};