const loadPost = require("../data/post_body");
const fUtil = require("../misc/file");
const base = Buffer.alloc(1, 0);
const asset = require("./main");
const http = require("http");

/**
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 * @param {import("url").UrlWithParsedQuery} url
 * @returns {boolean}
 */
module.exports = function (req, res, url) {
	var makeZip = false;
  var makeJson = false;
	switch (url.pathname) {
		case "/goapi/getUserAssets/":
                case "/goapi/getCommunityAssets/": {
			makeZip = true;
			break;
                }
    case "/api_v2/assets/imported":
    case "/api_v2/assets/team":
    case "/api_v2/assets/shared":
			makeJson = true;
			break;
		case "/goapi/getUserAssetsXml/":
			break;
		default:
			return;
	}

	switch (req.method) {
		case "GET": {
			var q = url.query;
			if (q.type) {
				asset.meta2Xml(q, makeZip, makeJson).then((buff) => {
					const type = makeZip ? "application/zip" : makeJson ? "application/json" : "application/xml";
					res.setHeader("Content-Type", type);
					res.end(buff);
				});
				return true;
			} else return;
		}
		case "POST": {
			loadPost(req, res).then(data => asset.meta2Xml(makeJson ? data.data : data, makeZip, makeJson))
			.then((buff) => {
				const type = makeZip ? "application/zip" : makeJson ? "application/json" : "application/xml";
				res.setHeader("Content-Type", type);
				if (makeZip) res.write(base);
				res.end(buff);
			});
			return true;
		}
		default:
			return;
	}
};