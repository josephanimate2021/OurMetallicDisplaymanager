const fUtil = require("../misc/file");
const parse = require("./parse");
const retroParse = require("./parseOld");
const fs = require("fs");
const get = require("../misc/get");
function p(type, ext, suffix) {
  return fUtil.getFileIndex(`${type}-`, `.${ext}`, suffix)
}
module.exports = {
	/**
	 *
	 * @param {Buffer} movieZip
	 * @param {string} nëwId
	 * @param {string} oldId
	 * @returns {Promise<string>}
	 */
	save(movieZip, thumb, isStarter = false, large, mId) {
                // why save user info if you are not going to list starters.
                var sId;
                if (isStarter) sId = `s-${fUtil.getNextFileId("starter-", ".xml")}`;
                mId ||= `m-${fUtil.getNextFileId("movie-", ".xml")}`;
		// Saves the thumbnail of the respective video.
		if (thumb) {
                        var n;
			if (isStarter) {
                                var i = sId.indexOf("-");
                                n = sId.substring(i + 1);
                        } else n = Number.parseInt(mId.substr(2));
			var thumbFile = fUtil.getFileIndex("thumb-", ".png", n);
                        const largeThumb = fUtil.getFileIndex("movie-", ".png", n);
                        if (isStarter) thumbFile = fUtil.getFileIndex("starter-", ".png", n);
			fs.writeFileSync(thumbFile, thumb);
                        if (!isStarter) fs.writeFileSync(largeThumb, large);
		}
                if (isStarter) mId = sId;
		return new Promise(async (res, rej) => {
			var i = mId.indexOf("-");
			var prefix = mId.substr(0, i);
			var suffix = mId.substr(i + 1);
			switch (prefix) {
				case "m": {
					var path = p("movie", "xml", suffix);
                                        await parse.unpackSingle(movieZip, path, suffix);
                                        res(mId);
                                        break;
				} case "s": {
                                        var path = p("starter", "xml", suffix);
                                        await parse.unpackSingle(movieZip, path, suffix);
                                        this.meta(mId).then(m => {
                                                fs.writeFileSync(`./meta/starter/tags/${m.id}.txt`, m.tag);
                                                fs.writeFileSync(`./meta/starter/titles/${m.id}.txt`, m.title);
                                                res(m.id);
                                        });
                                }
			}
		});
	},
        saveRetro(body, thumb, large, data) {
                let user, mId;
                if (!data.userId && !data.username) {
                        user = {
                                name: "Guest User",
                                id: "9856859",
                                videomaker: data.ctc
                        }
                } else if (!data.usrUrl) {
                        user = {
                                name: data.username,
                                id: data.userId,
                                videomaker: data.ctc
                        }
                } else {
                        user = {
                                name: data.username,
                                url: data.usrUrl,
                                profileImage: data.usrImg || "",
                                id: data.userId,
                                videomaker: data.ctc
                        }
                }
                if (!data.movieId) mId = `m-${fUtil.getNextFileId('movie-', '.xml')}`;
                else mId = data.movieId;
		// Saves the thumbnail of the respective video.
                const [ prefix, suffix ] = mId.split("-");
		if (thumb) {
                        var thumbFile = fUtil.getFileIndex("thumb-", ".png", suffix);
                        const largeThumb = fUtil.getFileIndex("movie-", ".png", suffix);
                        fs.writeFileSync(thumbFile, thumb);
                        fs.writeFileSync(largeThumb, large);
                }
		return new Promise(async (res, rej) => {
                        fs.writeFileSync(fUtil.getFileIndex('movie-', '.xml', suffix), body);
                        fs.writeFileSync(p("user", "json", suffix), JSON.stringify(user));
                        res(mId);
		});
	},
        getStockThumb(tray) {
        return new Promise((res, rej) => {
                get(`https://raw.githubusercontent.com/Wrapper-Offline/Wrapper-Offline/main/server/pages/img/themes/${tray}.jpg`).then(buffer => {
                        res(buffer)
                }).catch(e => {
                        get(`https://raw.githubusercontent.com/Wrapper-Offline/Wrapper-Offline/main/server/pages/img/themes/${tray}.png`).then(buff => {
                                res(buff)
                        }).catch(e => rej(e));
                });
        });
},
async loadZip(mId) {
        const meta = await this.meta(mId);
    const [ prefix, suffix ] = mId.split("-");
    var filepath, thumbpath;
    switch (prefix) {
      case "m": {
        filepath = fUtil.getFileIndex("movie-", ".xml", suffix);
        thumbpath = fUtil.getFileIndex("thumb-", ".png", suffix);
        largepath = fUtil.getFileIndex("movie-", ".png", suffix);
        break;
      } case "s": {
        filepath = fUtil.getFileIndex("starter-", ".xml", suffix);
        thumbpath = fUtil.getFileIndex("starter-", ".png", suffix);
        // turn largepath into false array
        largepath = fUtil.getFileIndex("sl-", ".png", suffix);
        break;
      }
    }
    try {
            return await parse.pack(fs.readFileSync(filepath), fs.readFileSync(thumbpath), fs.existsSync(largepath) ? fs.readFileSync(largepath) : false);
    } catch (e) {
      console.log(e);
      return null;
    }
},
loadThumb(movieId, large = false) {
	return new Promise((res, rej) => {
                try {
                        const n = Number.parseInt(movieId.substr(2));
                        var fn;
                        if (large) fn = fUtil.getFileIndex("movie-", ".png", n);
                        else if (movieId.startsWith("s-")) fn = fUtil.getFileIndex("starter-", ".png", n);
                        else fn = fUtil.getFileIndex("thumb-", ".png", n);
                        res(fs.readFileSync(fn));
                } catch (e) {
                        rej(e);
                }
	});
},
async delete(mId) {
        try {
                const [ prefix, suffix ] = mId.split("-");
                const paths = [
                        `${fUtil.getFileIndex("movie-", ".xml", suffix)}`,
                        `${fUtil.getFileIndex("thumb-", ".png", suffix)}`,
                        `${fUtil.getFileIndex("movie-", ".png", suffix)}`,
                ];
                for (const dirs of paths) fs.unlinkSync(dirs);
                return {
                        code: "0",
                        url: "/static/domo/list.html",
                }
        } catch (e) {
                console.log(e);
                return {
                        code: "1",
                        error: "Movie deleting has failed. Please try again later."    
                }
        }
},
list() {
        const array = [];
        const last = fUtil.getLastFileIndex("movie-", ".xml");
        for (let c = last; c >= 0; c--) {
          const movie = fs.existsSync(fUtil.getFileIndex("movie-", ".xml", c));
          const thumb = fs.existsSync(fUtil.getFileIndex("thumb-", ".png", c));
          if (movie && thumb) array.push(`m-${c}`);
        }
        return array;
},
async listStaffMovies() {
    const array = [];
    const id = fUtil.getValidFileIndicies("movie-", ".xml");
    for (const ids of id) {
      const movie = fs.existsSync(fUtil.getFileIndex("movie-", ".xml", ids));
      const thumb = fs.existsSync(fUtil.getFileIndex("thumb-", ".png", ids));
      const info = await this.meta(`m-${ids}`);
      if (movie && thumb && !info.user.name.startsWith("Guest") && !info.user.roles) array.push(info);
    }
    return array;
},
async listGuestMovies() {
    const array = [];
    const id = fUtil.getValidFileIndicies("movie-", ".xml");
    for (const ids of id) {
      const movie = fs.existsSync(fUtil.getFileIndex("movie-", ".xml", ids));
      const thumb = fs.existsSync(fUtil.getFileIndex("thumb-", ".png", ids));
      const info = await this.meta(`m-${ids}`);
      if (movie && thumb && info.user.name.startsWith("Guest")) array.push(info);
    }
    return array;
},
meta(movieId) {
	return new Promise(async (res, rej) => {
                try {
                        const [ prefix, suffix ] = movieId.split("-");
                        var fn = p("movie", "xml", suffix);
                        if (movieId.startsWith("s-")) fn = p("starter", "xml", suffix);
                        const buffer = fs.readFileSync(fn);
                        var begTitle, endTitle, begTag, endTag, title, tag;
                        begTitle = buffer.indexOf("<title>") + 16;
                        endTitle = buffer.indexOf("]]></title>");
                        begTag = buffer.indexOf("<tag>") + 14;
                        endTag = buffer.indexOf("]]></tag>");
                        if (buffer.includes("<title/>")) title = "Untitled Video";
                        else title = buffer.slice(begTitle, endTitle).toString();
                        if (buffer.includes("<tag/>")) tag = "none";
                        else tag = buffer.slice(begTag, endTag).toString();
                        const begPublish = buffer.indexOf('published="') + 11;
                        const endPublish = buffer.indexOf('"', begPublish);
                        const published = Number.parseFloat(buffer.slice(begPublish, endPublish).toString());
                        const begPshare = buffer.indexOf('pshare="') + 8;
                        const endPshare = buffer.indexOf('"', begPshare);
                        const pshare = Number.parseFloat(buffer.slice(begPshare, endPshare).toString());
                        const begDuration = buffer.indexOf('duration="') + 10;
                        const endDuration = buffer.indexOf('"', begDuration);
                        const duration = Number.parseFloat(buffer.slice(begDuration, endDuration));
                        const min = ("" + ~~(duration / 60)).padStart(2, "0");
                        const sec = ("" + ~~(duration % 60)).padStart(2, "0");
                        const durationStr = `${min}:${sec}`;
                        var draft = false; 
                        var private = false;
                        if (published == "0") draft = true;
                        if (pshare == "1") {
                                private = true;
                                draft = false;
                        }
                        res({
                                date: fs.statSync(fn).mtime,
                                durationString: durationStr,
                                title: title || "Untitled Video",
                                id: movieId,
                                tag: tag || "none",
                                hidden: fs.existsSync(p("hidden-movie", "txt", suffix)),
                                draft: draft,
                                published: published,
                                pShared: pshare,
                                private: private,
                        });
                } catch (e) {
                        rej(e);
                }
	});
},
metaWithoutPromise(movieId) {
        try {
                const [ prefix, suffix ] = movieId.split("-");
                var fn = p("movie", "xml", suffix);
                if (movieId.startsWith("s-")) fn = p("starter", "xml", suffix);
                const buffer = fs.readFileSync(fn);
                var begTitle, endTitle, begTag, endTag, title, tag;
                begTitle = buffer.indexOf("<title>") + 16;
                endTitle = buffer.indexOf("]]></title>");
                begTag = buffer.indexOf("<tag>") + 14;
                endTag = buffer.indexOf("]]></tag>");
                if (buffer.includes("<title/>")) title = "Untitled Video";
                else title = buffer.slice(begTitle, endTitle).toString();
                if (buffer.includes("<tag/>")) tag = "none";
                else tag = buffer.slice(begTag, endTag).toString();
                const begPublish = buffer.indexOf('published="') + 11;
                const endPublish = buffer.indexOf('"', begPublish);
                const published = Number.parseFloat(buffer.slice(begPublish, endPublish).toString());
                const begPshare = buffer.indexOf('pshare="') + 8;
                const endPshare = buffer.indexOf('"', begPshare);
                const pshare = Number.parseFloat(buffer.slice(begPshare, endPshare).toString());
                const begDuration = buffer.indexOf('duration="') + 10;
                const endDuration = buffer.indexOf('"', begDuration);
                const duration = Number.parseFloat(buffer.slice(begDuration, endDuration));
                const min = ("" + ~~(duration / 60)).padStart(2, "0");
                const sec = ("" + ~~(duration % 60)).padStart(2, "0");
                const durationStr = `${min}:${sec}`;
                var draft = false; 
                var private = false;
                if (published == "0") draft = true;
                if (pshare == "1") {
                        private = true;
                        draft = false;
                }
                return {
                        date: fs.statSync(fn).mtime,
                        durationString: durationStr,
                        title: title || "Untitled Video",
                        id: movieId,
                        tag: tag || "none",
                        hidden: fs.existsSync(p("hidden-movie", "txt", suffix)),
                        draft: draft,
                        published: published,
                        pShared: pshare,
                        private: private,
                }
        } catch (e) {
                console.log(e);
        }

},
};
