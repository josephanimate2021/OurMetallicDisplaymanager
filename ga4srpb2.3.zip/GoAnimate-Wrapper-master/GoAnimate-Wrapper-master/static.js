const get = require("./misc/get");
const fs = require("fs");
const http = require("http");

/**
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 * @param {import("url").UrlWithParsedQuery} url
 * @returns {boolean}
 */
module.exports = function (req, res, url) {
	var path = url.pathname;
	if (req.method != "GET" || !path.startsWith("/animation/414827163ad4eb60") && !path.startsWith("/store/3a981f5cb2739137") && !path.startsWith("/static/ad44370a650793d9") && !path.startsWith("/static")) return;
	if (path.includes("swf")) res.setHeader("Content-Type", "application/x-shockware-flash")
	try {
		if (path.includes("/static")) {
			if (path.includes("/static/ad44370a650793d9")) get(`https://bluepeacocks.github.io/NewGA4SRCloudfrontServer${path}`).then((v) => res.end(v));
			else {
				if (path.includes("css")) res.setHeader("Content-Type", "text/css");
				if (path.includes("js")) res.setHeader("Content-Type", "text/javascript");
				res.end(fs.readFileSync(`.${path}`));
			}
		}
		else get(`https://bluepeacocks.github.io/NewGA4SRCloudfrontServer${path}`).then((v) => res.end(v));
	} catch (e) {
		console.log(e);
	}
	return true;
};