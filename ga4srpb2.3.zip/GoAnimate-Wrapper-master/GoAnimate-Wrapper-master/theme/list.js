const loadPost = require("../misc/post_body");
const header = process.env.XML_HEADER;
const ffmpeg = require("fluent-ffmpeg");
ffmpeg.setFfmpegPath(require("@ffmpeg-installer/ffmpeg").path);
ffmpeg.setFfprobePath(require("@ffprobe-installer/ffprobe").path);
const { Readable } = require("stream");
const movie = require("../movie/main");
const cachéFolder = process.env.CACHÉ_FOLDER;
const base = Buffer.alloc(1, 0);
const mp3Duration = require("mp3-duration");
const info = require("../tts/info"), voices = info.voices, langs = {};
const asset = require("../asset/main");
const character = require("../character/main");
const util = require("../misc/util");
const fUtil = require("../misc/file");
const fs = require("fs");
const tts = require("../tts/main");
const http = require("http");
const caché = require("../asset/caché");
const formidable = require("formidable");
const nodezip = require("node-zip");
var makeZip = false;
async function listAssets(data, makeZip) {
	var xmlString, files;
	switch (data.type) {
		case "char": {
			files = await asset.chars(data.themeId);
			xmlString = `${header}<ugc more="0">${files
				.map(
					(v) =>
						`<char id="${v.id}" name="Untitled" cc_theme_id="${v.theme}" thumbnail_url="/char_thumbs/${v.id}.png" copyable="Y"><tags/></char>`
				)
				.join("")}</ugc>`;
			break;
		}
		case "bg": {
			files = asset.list("bg");
			xmlString = `${header}<ugc more="0">${files
				.map((v) => `<background subtype="0" id="${v.id}" name="${v.name}" enable="Y"/>`)
				.join("")}</ugc>`;
			break;
		}
		case "sound": {
			files = asset.list("sound");
			xmlString = `${header}<ugc more="0">${files
				.map(
					(v) =>
						`<sound subtype="${v.subtype}" id="${v.id}" name="${v.name}" enable="Y" duration="${v.duration}" downloadtype="progressive"/>`
				)
				.join("")}</ugc>`;
			break;
		}	
		case "movie": {
			files = movie.starters();
			xmlString = `${header}<ugc more="0">${files
				.map(
					(v) =>
						`<movie id="${v.id}" enc_asset_id="${v.id}" path="/_SAVED/${v.id}" numScene="1" title="${v.name}" thumbnail_url="/movie_thumbs/${v.id}.png"><tags>${v.tag || ""}</tags></movie>`
				)
				.join("")}</ugc>`;
			break;
		}
		case "prop": {
			files = asset.list("prop");
			xmlString = `${header}<ugc more="0">${files
				.map(
					(v) =>
						`<prop subtype="0" id="${v.id}" name="${v.name}" enable="Y" holdable="0" headable="0" placeable="1" facing="left" width="0" height="0" asset_url="/assets/${v.id}"/>`
				)
				.join("")}</ugc>`;
			break;
		}
		default: {
			files = asset.list("watermarks");
			xmlString = `${header}<watermarks>${files.map(w => asset.waterMarkMeta2Xml(data, w))}</watermarks>`;
			console.log(xmlString);
			break;
		}
	}

	if (makeZip) {
		const zip = nodezip.create();
		fUtil.addToZip(zip, "desc.xml", Buffer.from(xmlString));
		if (data.type == "movie") return await zip.zip();
		else for (const file of files) {
			const buffer = fs.readFileSync(`./${file.mode}/${file.id}`);
			fUtil.addToZip(zip, `${file.mode}/${file.id}`, buffer);
		}
		return await zip.zip();
	} else return Buffer.from(xmlString);
}
function createMetaFolders(mode) {
	try {
		const dirs = ['./meta', `./meta/${mode}`, `./meta/${mode}/titles`, `./meta/${mode}/tags`];
		for (const dir of dirs) {
			if (!fs.existsSync(dir)) fs.mkdirSync(dir);
		}
	} catch (e) {
	  console.log(e);
	}
}
function createIdFolders(id) {
	try {
		const dirs = ['./meta', `./meta/${id}`];
		for (const dir of dirs) {
			if (!fs.existsSync(dir)) fs.mkdirSync(dir);
		}
	} catch (e) {
	  console.log(e);
	  return;
	}
	return true;
}
function createTypeFolders(mode) {
	const type = mode == "sound" ? "sounds" : mode;
	const folder = `./${type}`;
	try {
		if (!fs.existsSync(folder)) fs.mkdirSync(folder);
	} catch (e) {
		console.log(e);
	}
}
const folder = process.env.THEME_FOLDER;

/**
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 * @param {import("url").UrlWithParsedQuery} url
 * @returns {boolean}
 */
module.exports = function (req, res, url) {
	if (req.method != "POST") return; 
	switch (url.pathname) {
		case "/goapi/getThemeList/": {
			res.setHeader("Content-Type", "application/zip");
			fUtil.makeZip(`${folder}/_themelist.xml`, "themelist.xml").then((b) => res.end(b));
			break;
		} case "/goapi/saveCCCharacter/": {
			loadPost(req, res).then(([data]) => {
				character.save(Buffer.from(data.body)).then((id) => {
					var thumb = Buffer.from(data.thumbdata, "base64");
					character.saveThumb(thumb, id);
					res.end(`0${id}`);
				}).catch(e => res.end(`1` + e))
			});
			break;
		}
		case "/goapi/saveCCThumbs/": {
			loadPost(req, res).then(([data]) => {
				var id = data.assetId;
				var thumb = Buffer.from(data.thumbdata, "base64");
				character.saveThumb(thumb, id);
				res.end(`0${id}`);
			});
			break;
		} case "/ajax/char/upload": {
			new formidable.IncomingForm().parse(req, async (e, f, files) => {
				const path = files.import.path;
				const buffer = fs.readFileSync(path);
				const xml = buffer.toString("utf8");
				if (!xml.includes("cc_char") || files.import.type != "text/xml") {
					res.statusCode = 302;
					res.setHeader("Location", "/");
					res.end();
				} else {
					const meta = await parse.unpackCharXml(buffer);
					res.statusCode = 302;
					res.setHeader("Location", `/character_creator/copy/c-${meta.id}?themeId=${meta.tId}`);
					res.end();
				}
			});
			break;
		} case "/goapi/convertTextToSoundAsset/": {
			loadPost(req, res).then(([data, mId]) => {
				tts(data.voice, data.text).then((buffer) => {
					mp3Duration(buffer, (e, d) => {
						var dur = d * 1e3;
						if (e || !dur) return res.end(1 + util.xmlFail("Unable to retrieve MP3 stream."));

						const title = `[${voices[data.voice].desc}] ${data.text}`;
						createMetaFolders("tts");
						const id = asset.saveTTS(buffer, mId, "tts", "mp3");
						fs.writeFileSync(`./meta/tts/titles/${id.split(".")[0]}.txt`, title);
						res.end(`0<response><asset><id>${id}</id><enc_asset_id>${
							id
						}</enc_asset_id><type>sound</type><subtype>tts</subtype><title>${
							title
						}</title><published>0</published><tags></tags><duration>${
							dur
						}</duration><downloadtype>progressive</downloadtype><file>${
							id
						}</file></asset></response>`);
					});
				}).catch((e) => {
					console.log(e);
					res.end(`1<error><code>ERR_ASSET_404</code><message>${e}</message><text></text></error>`);
				});
			});
			break;
		} case "/goapi/getTextToSpeechVoices/": {
			Object.keys(voices).forEach((i) => {
				const v = voices[i],
					l = v.language;
				langs[l] = langs[l] || [];
				langs[l].push(`<voice id="${i}" desc="${v.desc}" sex="${v.gender}" demo-url="" country="${v.country}" plus="N"/>`);
			});
			
			const xml = `${process.env.XML_HEADER}<voices>${Object.keys(langs)
				.sort()
				.map((i) => {
					const v = langs[i],
						l = info.languages[i];
					return `<language id="${i}" desc="${l}">${v.join("")}</language>`;
				})
				.join("")}</voices>`;
			res.setHeader("Content-Type", "application/xml");
			res.end(xml);
			break;			
		} case "/goapi/getMovie/": {
			async function loadMovie() {
				return Buffer.concat([base, await movie.loadZip(url.query.movieId)]);
			}
			loadMovie().then(b => {
				res.setHeader("Content-Type", "application/zip");
				res.end(b)
			}).catch(e => {
				console.log(e);
				res.end("1" + e);
			});
			break;
		} case "/goapi/getMovieInfo/": {
			loadPost(req, res).then(([data, mId]) => {
				if (!fs.existsSync(`./meta/${mId}/watermark.txt`)) {
					res.end(`<watermarks><watermark style="g4s"/></watermarks>`);
				} else res.end(fs.readFileSync(`./meta/${mId}/watermark.txt`, 'utf8'));
			});
			break;
		} case "/goapi/saveMovie/": {
			loadPost(req, res).then(([data]) => {
				const body = Buffer.from(data.body_zip, "base64");
				const saveThumb = data.save_thumbnail;
				const trigAutoSave = data.is_triggered_by_autosave;
				let thumb;
				if (saveThumb && !trigAutoSave) thumb = Buffer.from(data.thumbnail_large, "base64");
				else thumb = movie.getRandomThumb();
				movie.save(body, thumb, data.presaveId).then(id => {
					if (createIdFolders(id)) {
						if (!fs.existsSync(`./meta/${id}/watermark.txt`)) {
							fs.writeFileSync(`./meta/${id}/watermark.txt`, fs.existsSync(`./meta/watermark/default.txt`) ? fs.readFileSync(`./meta/watermark/default.txt`, 'utf8') : `<watermarks><watermark style="bluepeacocks"/></watermarks>`);
						}
					}
					res.end(0 + id);
				});
			});
			break;
		} case "/goapi/getWaveform/": {
			loadPost(req, res).then(([data, mId]) => {
				try {
					if (data.wftheme == "ugc") res.end(fs.readFileSync(`${cachéFolder}/${
						data.wfid.slice(0, -4)
					}.wf`));
					else {
						get(`${process.env.STORE_URL}/${data.wftheme}/sound/${data.wfid}`).then(buffer => {
							res.end(buffer);
						});
					}
				} catch (e) {
					try {
						res.end(fs.readFileSync(`./sounds/${data.wfid}`));
					} catch (e) {
						res.end(caché.load(mId, data.wfid));
					}
				}
			});
			break;
		}
		case "/goapi/saveWaveform/": {
			loadPost(req, res).then(([data]) => {
				if (!fs.existsSync(cachéFolder)) fs.mkdirSync(cachéFolder);
				fs.writeFileSync(`${cachéFolder}/${data.wfid.slice(0, -4)}.wf`, data.waveform);
			});
			break;
		}
		case "/ajax/saveUserProp": {
			new formidable.IncomingForm().parse(req, (e, f, files) => {
				try {
					if (e) res.end(JSON.stringify({suc: false, msg: e}));
					else if (!files) {
						res.end(JSON.stringify({
							suc: false,
							msg: "Please choose a file to upload"
						}));
					} else if (!f || !f.subtype) {
						res.end(JSON.stringify({
							suc: false,
							msg: "File upload failed. Missing one or more fields."
						}));
					} else {
						const id = fUtil.generateId();
						const type = f.subtype == "soundeffect" ||
						f.subtype == "voiceover" || f.subtype == "bgmusic" ? "sound" : f.subtype;
						createMetaFolders(f.subtype);
						const file = files.file || files.import;
						const path = file.path;
						const name = file.name;
						const dot = name.lastIndexOf(".");
						const ext = name.substr(dot + 1);
						const newName = `${id}-${f.subtype}.${ext}`;
						const buffer = fs.readFileSync(path);
						var folder;
						if (type == "sound") folder = "./sounds";
						else if (type == "watermark") folder = "./watermarks";
						else folder = `./${type}`;
						createTypeFolders(folder);
						fs.writeFileSync(`${folder}/${newName}`, buffer);  
						fs.writeFileSync(`./meta/${f.subtype}/titles/${id}-${f.subtype}.txt`, name);
						const info = {
							suc: true,
							// gives meta for the importer js file to read
							id: newName,
							asset_type: type,
							filename: name,
							asset_data: {
								file: newName,
								title: name,
								subtype: f.subtype
							}
						}
						switch (type) {
							case "watermark": {
								res.statusCode = 302;
								res.setHeader("Location", "/html/watermark.html");
								res.end();
								break;
							} case "prop": {
								info.thumbnail = `/assets/${newName}`;
								info.asset_data.ptype = "placeable";
								res.end(JSON.stringify(info));
								break;
							} case "sound": {
								fUtil.duration(buffer).then(dur => {
									info.asset_data.duration = dur;
									info.duration = dur;
									info.asset_data.downloadtype = "progressive";
									fs.writeFileSync(`./meta/${f.subtype}/${id}.json`, JSON.stringify(info))
									res.end(JSON.stringify(info));
								}).catch(e => {
									res.end(JSON.stringify({
										suc: false,
										msg: `File upload failed. ${e}`
									}));
								})
								break;
							} default: {
								info.thumbnail = `/assets/${newName}`;
								res.end(JSON.stringify(info));
								break;
							} 
						}
						fs.unlinkSync(path);
					}
				} catch (e) {
					console.log(e);
					res.end(JSON.stringify({
						suc: false, 
						msg: "File Upload Failed. Please check your command prompt for more details."
					}));
				}
			});
			break;
		}
		case "/goapi/saveSound/": {
			new formidable.IncomingForm().parse(req, (e, f, files) => {
				if (e) res.end(1 + `<error><code>ERR_ASSET_404</code><message>${e || `Unable to save your asset. One or more fields are missing.`}</message><text></text></error>`);
				/**
				 * Saves a sound asset
				*/
				async function saveSound(data) {
					isRecord = data.bytes ? true : false;

					let oldStream, stream, ext;
					if (isRecord) {
						const buffer = Buffer.from(data.bytes, "base64");
						oldStream = Readable.from(buffer);
						ext = "ogg";
					} else {
						// read the file
						const path = files.Filedata.path;
						oldStream = fs.createReadStream(path);
						// get the extension
						const origName = data.Filename;
						const dotIn = origName.lastIndexOf(".");
						ext = origName.substring(dotIn + 1);
					}
					let meta = {
						type: "sound",
						subtype: data.subtype,
						title: data.title,
						ext: "mp3",
						themeId: "ugc"
					};
			
					if (ext !== "mp3") {
						await new Promise((resolve, rej) => {
							// convert the sound to an mp3
							const command = ffmpeg(oldStream).inputFormat(ext).toFormat("mp3").on("error", rej);
							stream = command.pipe();
							resolve();
						});
					} else stream = oldStream;

					let buffers = [];
					stream.resume().on("data", b => buffers.push(b)).on("end", () => {
						const buf = Buffer.concat(buffers);
						mp3Duration(buf, (e, duration) => {
							if (e || !duration) res.end(`1<error><code>ERR_ASSET_404</code><message>${e || `Unable to retrive sound duration. Current duration: ${duration}`}</message><text></text></error>`);
							meta.duration = 1e3 * duration;
							createMetaFolders(data.subtype);
							createTypeFolders(meta.type);
							const aId = asset.save(buf, meta);
							fs.writeFileSync(`./meta/${data.subtype}/${aId.split("-")[0]}.json`, JSON.stringify(meta));
							fs.writeFileSync(`./meta/${data.subtype}/titles/${aId.slice(0, -4)}.txt`, meta.title);
							res.end(`0<response><asset><id>${aId}</id><enc_asset_id>${
								aId
							}</enc_asset_id><type>sound</type><subtype>${meta.subtype}</subtype><title>${
								meta.title
							}</title><published>0</published><tags></tags><duration>${
								meta.duration
							}</duration><downloadtype>progressive</downloadtype><file>${
								aId
							}</file></asset></response>`);
						});
					}).on("error", (e) => {
						res.end(`1<error><code>ERR_ASSET_404</code><message>${e || `Unable to save your asset. One or more fields are missing.`}</message><text></text></error>`);
					});
				}
				saveSound(f);
			});
			break;
		}
		case "/goapi/saveTemplate/": {
			loadPost(req, res).then(([data]) => {
				const body = Buffer.from(data.body_zip, "base64");
				const thumb = Buffer.from(data.thumbnail, "base64");
				movie.save(body, thumb, data.movieId, true).then(id => res.end(0 + id));
			});
			break;
		} case "/goapi/getLatestAssetId/": {
			res.setHeader("Content-Type", "text/html; charset=UTF-8")
			res.end("0");
			break;
		} case "/goapi/deleteAsset/": {
			loadPost(req, res).then(([data]) =>  {
					const file = data.assetId;
					const aId = file.split(".")[0];
					const [ id, subtype ] = aId.split("-");
					var types = null;
					switch (subtype) {
							case "soundeffect":
							case "bgmusic":
							case "voiceover": {
									types = "sounds";
									break;
							}
					}
					fs.unlinkSync(`./${types || subtype}/${file}`);
					fs.unlinkSync(`./meta/${subtype}/titles/${aId}.txt`);
					if (fs.existsSync(`./meta/${subtype}/${id}.json`)) 
							fs.unlinkSync(`./meta/${subtype}/${id}.json`);
			});
			break;
		} 
		case "/goapi/updateSysTemplateAttributes/":
		case "/goapi/updateAsset/": {
			loadPost(req, res).then(([data]) => {
					const file = data.assetId || data.movieId;
					var aId, subtype;
					if (file.startsWith("s-")) {
						aId = data.movieId;
						subtype = "starter";
					} else {
						aId = file.split(".")[0];
						subtype = aId.split("-")[1];
					}
					fs.writeFileSync(`./meta/${subtype}/titles/${aId}.txt`, data.title);
					fs.writeFileSync(`./meta/${subtype}/tags/${aId}.txt`, data.tags);
			});
			break;
		} case "/api_v2/studio_preference/get": {
			res.statusCode = 200;
			res.end(JSON.stringify({status: "ok", data: [{
				category: {
					favorite: {
						template: {
							business: ["office"]
						}
					}, featured: {
						template: {
							business: []
						}
					}
				}
			}]}));
			break;
		} case "/goapi/getUserAssets/": makeZip = true;
		case "/goapi/getUserAssetsXml/":
		case "/goapi/getUserWatermarks/": {
			loadPost(req, res).then(([data]) => listAssets(data, makeZip)).then((buff) => {
				res.setHeader("Content-Type", `application/${makeZip ? "zip" : "xml"}`);
				if (makeZip) res.write(base);
				res.end(buff);
			});
			break;
		}
	}
	return true;
};
