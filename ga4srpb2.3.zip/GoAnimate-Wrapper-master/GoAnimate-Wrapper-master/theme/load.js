const loadPost = require("../misc/post_body");
const get = require("../misc/get");
const nodezip = require("node-zip");
const fUtil = require("../misc/file");
const http = require("http");

/**
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 * @param {import("url").UrlWithParsedQuery} url
 * @returns {boolean}
 */
module.exports = function (req, res, url) {
	if (req.method != "POST" || url.path != "/goapi/getTheme/") return;
	loadPost(req, res).then(([data]) => {
		var theme = data.themeId;
		switch (theme) {
			case "family":
				theme = "custom";
				break;
		}
		get(process.env.STORE_URL + `/${theme}/theme.xml`).then(async b => {
			const zip = nodezip.create();
			fUtil.addToZip(zip, "theme.xml", b);
			res.setHeader("Content-Type", "application/zip");
			res.end(await zip.zip());
		});
	});
	return true;
};
