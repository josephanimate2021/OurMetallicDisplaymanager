module.exports = function (req, res, url) {
	if (req.method != "POST" || !url.pathname.startsWith("/goapi/assignwatermark/")) return;
	const pieces = url.pathname.split("/");
	const mId = pieces[4];
	const wId = pieces[5];
	console.log(mId, wId);
};
