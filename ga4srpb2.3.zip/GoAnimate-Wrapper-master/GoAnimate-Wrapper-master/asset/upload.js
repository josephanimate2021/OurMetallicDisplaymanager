/**
 * Asset Importing
 */
// modules
const ffmpeg = require("fluent-ffmpeg");
ffmpeg.setFfmpegPath(require("@ffmpeg-installer/ffmpeg").path);
ffmpeg.setFfprobePath(require("@ffprobe-installer/ffprobe").path);
const { Readable } = require("stream");
const mp3Duration = require("mp3-duration");
const asset = require("./main");
const loadPost = require("../misc/post_body");
const formidable = require("formidable");
const movie = require("../movie/main");
const http = require("http");
const fs = require("fs");

// stuff
/**
 * creates meta folders for a subtype if they don't exist
 */
function createMetaFolders(mode) {
	try {
		if (!fs.existsSync('./meta')) fs.mkdirSync('./meta');
		if (!fs.existsSync(`./meta/${mode}`)) fs.mkdirSync(`./meta/${mode}`);
		if (!fs.existsSync(`./meta/${mode}/titles`)) fs.mkdirSync(`./meta/${mode}/titles`);
		return true;
	} catch (e) {
	  console.log(e);
	}
}
/**
 * creates type folders that don't exist.
 */
function createTypeFolders(mode) {
	const type = mode == "sound" ? "sounds" : mode;
	const folder = `./${type}`;
	try {
		if (!fs.existsSync(folder)) fs.mkdirSync(folder);
	} catch (e) {
		console.log(e);
	}
}
/**
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 * @param {import("url").UrlWithParsedQuery} url
 * @returns {boolean}
 */
module.exports = function (req, res, url) {
	if (req.method != "POST") return;
	switch (url.pathname) {
		case "/ajax/saveUserProp": { // using the legacy importer
			new formidable.IncomingForm().parse(req, (e, f, files) => {
				try {
					if (e) res.end(JSON.stringify({suc: false, msg: e}));
					else if (!files) {
						res.end(JSON.stringify({
							suc: false,
							msg: "Please choose a file to upload"
						}));
					} else if (!f || !f.subtype) {
						res.end(JSON.stringify({
							suc: false,
							msg: "File upload failed. Missing one or more fields."
						}));
					} else {
						const id = fUtil.generateId();
						const type = f.subtype == "soundeffect" ||
						f.subtype == "voiceover" || f.subtype == "bgmusic" ? "sound" : f.subtype;
						createMetaFolders(f.subtype);
						const file = files.file;
						const path = file.filepath;
						const name = file.originalFilename;
						const dot = name.lastIndexOf(".");
						const ext = name.substr(dot + 1);
						const newName = `${id}-${f.subtype}.${ext}`;
						const buffer = fs.readFileSync(path);
						var folder;
						if (type == "sound") folder = "./sounds";
						else folder = `./${type}`;
						createTypeFolders(folder);
						fs.writeFileSync(`${folder}/${newName}`, buffer);  
						fs.writeFileSync(`./meta/${f.subtype}/titles/${id}-${f.subtype}.txt`, name);
						const info = {
							suc: true,
							// gives meta for the importer js file to read
							id: newName,
							asset_type: type,
							filename: name,
							asset_data: {
								file: newName,
								title: name,
								subtype: f.subtype
							}
						}
						switch (type) {
							case "prop": {
								info.thumbnail = `/assets/${newName}`;
								info.asset_data.ptype = "placeable";
								res.end(JSON.stringify(info));
								break;
							} case "sound": {
								mp3Duration(buf, (e, dur) => {
									if (e) {
										res.end(JSON.stringify({
											suc: false, 
											msg: `File Upload Failed. ${e}`
										}));
									}
									info.asset_data.duration = dur;
									info.duration = dur;
									info.asset_data.downloadtype = "progressive";
									fs.writeFileSync(`./meta/${f.subtype}/${id}.json`, JSON.stringify(info))
									res.end(JSON.stringify(info));
								})
								break;
							} default: {
								info.thumbnail = `/assets/${newName}`;
								res.end(JSON.stringify(info));
								break;
							} 
						}
						fs.unlinkSync(path);
					}
				} catch (e) {
					console.log(e);
					res.end(JSON.stringify({
						suc: false, 
						msg: "File Upload Failed. Please check your command prompt for more details."
					}));
				}
			});
			break;
		}
		case "/goapi/saveSound/": {
			new formidable.IncomingForm().parse(req, (e, f, files) => {
				if (e) res.end(1 + `<error><code>ERR_ASSET_404</code><message>${e || `Unable to save your asset. One or more fields are missing.`}</message><text></text></error>`);
				/**
				 * Saves a sound asset
				*/
				async function saveSound(data) {
					isRecord = data.bytes ? true : false;

					let oldStream, stream, ext;
					if (isRecord) {
						const buffer = Buffer.from(data.bytes, "base64");
						oldStream = Readable.from(buffer);
						ext = "ogg";
					} else {
						// read the file
						const path = files.Filedata.path;
						oldStream = fs.createReadStream(path);
						// get the extension
						const origName = data.Filename;
						const dotIn = origName.lastIndexOf(".");
						ext = origName.substring(dotIn + 1);
					}
					let meta = {
						type: "sound",
						subtype: data.subtype,
						title: data.title,
						ext: "mp3",
						themeId: "ugc"
					};
			
					if (ext !== "mp3") {
						await new Promise((resolve, rej) => {
							// convert the sound to an mp3
							const command = ffmpeg(oldStream).inputFormat(ext).toFormat("mp3").on("error", rej);
							stream = command.pipe();
							resolve();
						});
					} else stream = oldStream;

					let buffers = [];
					stream.resume().on("data", b => buffers.push(b)).on("end", () => {
						const buf = Buffer.concat(buffers);
						mp3Duration(buf, (e, duration) => {
							if (e || !duration) res.end(`1<error><code>ERR_ASSET_404</code><message>${e || `Unable to retrive sound duration. Current duration: ${duration}`}</message><text></text></error>`);
							meta.duration = 1e3 * duration;
							createMetaFolders(data.subtype);
							createTypeFolders(meta.type);
							const aId = asset.save(buf, meta);
							fs.writeFileSync(`./meta/${data.subtype}/${aId.split("-")[0]}.json`, JSON.stringify(meta));
							fs.writeFileSync(`./meta/${data.subtype}/titles/${aId.slice(0, -4)}.txt`, meta.title);
							res.end(`0<response><asset><id>${aId}</id><enc_asset_id>${
								aId
							}</enc_asset_id><type>sound</type><subtype>${meta.subtype}</subtype><title>${
								meta.title
							}</title><published>0</published><tags></tags><duration>${
								meta.duration
							}</duration><downloadtype>progressive</downloadtype><file>${
								aId
							}</file></asset></response>`);
						});
					}).on("error", (e) => {
						res.end(`1<error><code>ERR_ASSET_404</code><message>${e || `Unable to save your asset. One or more fields are missing.`}</message><text></text></error>`);
					});
				}
				saveSound(f);
			});
			break;
		}
		case "/goapi/saveTemplate/": {
			loadPost(req, res).then(([data]) => {
				var body = Buffer.from(data.body_zip, "base64");
				var thumb = Buffer.from(data.thumbnail, "base64");
				res.end("0" + movie.save(body, thumb, data.movieId, true));
			});
			break;
		}
	}
	return true;
};
