const chars = require("../character/main");
const fUtil = require("../misc/file");
const caché = require("./caché");
const fs = require("fs");
module.exports = {
	load(mId, aId, returnStream = false) {
		// only load tts buffers
		if (mId.startsWith("m-") || mId.startsWith("e-") && aId.includes("tts")) {
			if (returnStream) return caché.load(mId, aId, true);
			else return caché.load(mId, aId);
		}
		// load everything else
		else if (aId != "undefined") {
			const subtype = aId.split("-")[1].split(".")[0];
			const type = subtype == "voiceover" || subtype == "bgmusic" || subtype == "soundeffect" ? "sound" : subtype;
			const folder = type == "sound" ? "./sounds" : `./${type}`;
			if (returnStream) return fs.createReadStream(`${folder}/${aId}`);
			else return fs.readFileSync(`${folder}/${aId}`);
		}
	},
	waterMarkMeta2Xml(data, v) {
		const xml = fs.existsSync(`./meta/watermark/${data.presaveId}/watermark.txt`) ? fs.readFileSync(`./meta/watermark/${data.presaveId}/watermark.txt`) : fs.existsSync(`./meta/watermark/default.txt`) ? fs.readFileSync(`./meta/watermark/default.txt`, 'utf8') : "";
		var CurrentXml;
		if (xml.includes(v.id)) CurrentXml = `<current><watermark id="${v.id}" thumbnail="/assets/${v.id}"/></current>`;
		return `<watermark id="${v.id}" thumbnail="/assets/${v.id}"/>${CurrentXml}`;
	},
	/**
	 * Saves a TTS buffer in the cache so that asset listing does not list tts voices.
	 */
	saveTTS(buffer, mId, mode, ext) {
		var suffix = `-${mode}.${ext}`;
		return caché.newItem(buffer, mId, "", suffix);
	},
	/**
	 * Saves an asset
	 */
	save(buffer, meta) {
		const id = fUtil.generateId();
		const type = meta.subtype == "soundeffect" || meta.subtype == "bgmusic" ||
		meta.subtype == "voiceover" ? "sound" : meta.subtype;
		const folder = type == "sound" ? "./sounds" : `./${type}`;
		fs.writeFileSync(`${folder}/${id}-${meta.subtype}.${meta.ext}`, buffer);
		return `${id}-${meta.subtype}.${meta.ext}`;
	},
	/**
	 * Lists all assets by a subtype
	 */
	list(mode) {
		var subtype;
		if (mode == "watermarks") subtype = "watermark";
		else subtype = mode;
		const table = [];
		var folder = `./${mode}`;
		if (mode == "sound") folder = `./sounds`;
		if (!fs.existsSync(folder)) fs.mkdirSync(folder);
		fs.readdirSync(folder).forEach(file => {
			if (mode == "sound") {
				const [ id, sound ] = file.split("-");
				const subtype = sound.split(".")[0];
				const meta = require(`../meta/${subtype}/${id}.json`);
				const title = fs.readFileSync(`./meta/${subtype}/titles/${file.slice(0, -4)}.txt`);
				table.push({
					id: file, 
					name: title, 
					mode: mode,
					subtype: subtype, 
					duration: meta.duration
				});
			} else {
				const name = fs.readFileSync(`./meta/${subtype}/titles/${file.slice(0, -4)}.txt`, 'utf8')
				table.push({
					id: file, 
					name: name, 
					mode: mode
				});
			}
		});
		return table;
	},
	/**
	 * Lists all assets by an id
	 */
	listAll(mId) {
		var ret = [];
		var files = caché.list(mId);
		files.forEach((aId) => {
			var dot = aId.lastIndexOf(".");
			var dash = aId.lastIndexOf("-");
			var name = aId.substr(0, dash);
			var fMode = aId.substr(dash + 1, dot - dash - 1);
			ret.push({ id: aId, name: name, mode: fMode });
		});
		return ret;
	},
	/**
	 * Lists all characters
	 */
	chars(theme) {
		return new Promise(async res => {
			switch (theme) {
				case "custom":
					theme = "family";
					break;
				case "action":
				case "animal":
				case "space":
				case "vietnam":
					theme = "cc2";
					break;
			}

			var table = [];
			var ids = fUtil.getValidFileIndicies("char-", ".xml");
			for (const i in ids) {
				var id = `c-${ids[i]}`;
				if (!theme || theme == (await chars.getTheme(id))) {
					table.unshift({ theme: theme, id: id });
				}
			}
			res(table);
		});
	},
};
