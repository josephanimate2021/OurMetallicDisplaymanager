const movie = require("./main");
const base = Buffer.alloc(1, 0);
const http = require("http");

/**
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 * @param {import("url").UrlWithParsedQuery} url
 * @returns {boolean}
 */
module.exports = function (req, res, url) {
	switch (req.method) {
		case "GET": {
			const match = req.url.match(/\/movies\/([^.]+)(?:\.(zip|xml))?$/);
			if (!match) return;

			var id = match[1];
			var ext = match[2];
			switch (ext) {
				case "zip":
					res.setHeader("Content-Type", "application/zip");
					movie.loadZip(id).then((v) => {
						if (v) {
							res.statusCode = 200;
							res.end(v);
						} else {
							res.statusCode = 404;
							res.end();
						}
					});
					break;
				default:
					res.setHeader("Content-Type", "text/xml");
					movie.loadXml(id).then((v) => {
						if (v) {
							res.statusCode = 200;
							res.end(v);
						} else {
							res.statusCode = 404;
							res.end();
						}
					});
					break;
			}
			return true;
		}
		/*
		case "POST": {
			switch (url.path) {
				case "/goapi/getMovie/": {
					async function loadMovie() {
						return Buffer.concat([base, await movie.loadZip(url.query.movieId)]);
					}
					loadMovie().then(b => {
						res.setHeader("Content-Type", "application/zip");
						res.end(b); 
					}).catch(e => {
						console.log(e);
						res.end("1" + e);
					});
					break;
				} case "/goapi/getMovieInfo/": {
					res.end(`<?xml encoding="UTF-8"?><watermarks><watermark style="g4s"/></watermarks>`);
					break;
				}
			}
			return true;
		}*/
		default:
			return;
	}
};
