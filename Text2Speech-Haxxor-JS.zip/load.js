const load = require("./main");
const http = require("http");
const url = require("url");
const fs = require("fs");

http.createServer(async (req, res) => {
        res.statusCode = 403;
        const parsedUrl = url.parse(req.url, true);
        if (req.method == "GET") 
                switch (parsedUrl.pathname) {
                        case "/getVoices": {
                                res.statusCode = 200;
                                const json = JSON.parse(fs.readFileSync('./info.json'));
                                res.setHeader("Content-Type", "application/json");
                                res.end(JSON.stringify(json, null, '\t'));
                                break;
                        } case "/": {
                                const query = parsedUrl.query;
                                if (!query.voice && !query.text) {
                                        res.statusCode = 200;
                                        res.setHeader("Content-Type", "text/html; charset=utf8");
                                        res.end(fs.readFileSync(`./pages/home.html`));
                                } else if (!query.voice || !query.text) {
                                        res.statusCode = 200;
                                        res.end("Missing one of the required fields.")
                                } else 
                                        try {
                                                res.statusCode = 200;
                                                const buffer = await load(query.voice, query.text, query.pitch);
                                                res.setHeader("Content-Type", "audio/mp3");
                                                res.end(buffer);
                                        } catch (e) {
                                                res.statusCode = 500;
                                                console.log(e);
                                                res.end('Internal Server Error');
                                        }
                                break;
                        } default: {
                                if (fs.existsSync(`./pages${parsedUrl.pathname}`)) {
                                        res.statusCode = 200;
                                        res.setHeader("Content-Type", "text/html; charset=utf8");
                                        res.end(fs.readFileSync(`./pages${parsedUrl.pathname}`));
                                } else 
                                        try {
                                                res.statusCode = 404;
                                                res.setHeader("Content-Type", "text/html; charset=utf8");
                                                res.end(fs.readFileSync(`./pages/404.html`));
                                        } catch (e) {
                                                res.statusCode = 500;
                                                console.log(e);
                                                res.end('Internal Server Error');
                                        }
                                break;
                        }
                }
        console.log(req.method, req.url, '-', res.statusCode);
}).listen(8080);
