const brotli = require("brotli");
const ffmpeg = require("fluent-ffmpeg");
ffmpeg.setFfmpegPath(require("@ffmpeg-installer/ffmpeg").path);
function convertToMp3(data, fileExt) {
        return new Promise((res, rej) => {
		const command = ffmpeg(data).inputFormat(fileExt).toFormat("mp3").audioBitrate(4.4e4).on("error", rej);
                res(command.pipe());
	});
}
const https = require("https");
const voices = require("./info").voices;
const md5 = require("js-md5");

/**
 * uses tts demos to generate tts
 * @param {string} voiceName
 * @param {string} text
 * @returns {Promise<IncomingMessage>}
 */
module.exports = function processVoice(voiceName, text, pitch) {
	return new Promise(async (res, rej) => {
		const voice = voices[voiceName];
		if (!voice) return rej("The voice you requested is unavailable. Please try another voice.");

		try {
			switch (voice.source) {
				case "nextup": {
					const body = new URLSearchParams({
						msg: text,
						lang: voice.arg,
						source: "ttsmp3"
					}).toString();

					const req = https.request(
						{
							hostname: "ttsmp3.com",
							path: "/makemp3_new.php",
							method: "POST",
							headers: { 
								"Content-Length": body.length,
								"Content-type": "application/x-www-form-urlencoded"
							}
						},
						(r) => {
							let body = "";
							r.on("data", (c) => body += c);
							r.on("end", () => {
								const json = JSON.parse(body);
								if (json.Error == 1) {
									return rej(json.Text);
								}

								https
									.get(json.URL, (r) => {
                                                                                let buffers = [];
                                                                                r.on("data", (b) => buffers.push(b));
                                                                                r.on("end", () => res(Buffer.concat(buffers)));
                                                                        })
                                                                        .on("error", rej);
							});
							r.on("error", rej);
						}
					)
					req.on("error", rej);
					req.end(body);
					break;
				}

				case "cepstral": 
				case "voiceforge": {
					const q = new URLSearchParams({						
						msg: text,
						voice: voice.arg,
						email: "null"
					}).toString();
					
					https.get({
						hostname: "api.voiceforge.com",
						path: `/swift_engine?${q}`,
						headers: { 
							"User-Agent": "just_audio/2.7.0 (Linux;Android 11) ExoPlayerLib/2.15.0",
							"HTTP_X_API_KEY": "8b3f76a8539",
							"Accept-Encoding": "identity",
							"Icy-Metadata": "1",
						}
					}, (r) => {
						convertToMp3(r, "wav").then((v) => {
                                                        const buffers = [];
                                                        v.on("data", (b) => buffers.push(b));
                                                        v.on("end", () => res(Buffer.concat(buffers)));
                                                }).catch(rej);
					}).on("error", rej);
					break;
				}

				case "vocalware": {
                                        var [EID, LID, VID] = voice.arg;
                                        var cs = md5(`${EID}${LID}${VID}${text}1mp35883747uetivb9tb8108wfj`);
                                        var q = new URLSearchParams({
                                                EID,
                                                LID,
                                                VID,
                                                TXT: text,
                                                EXT: "mp3",
                                                IS_UTF8: 1,
                                                ACC: 5883747,
                                                cache_flag: 3,
                                                CS: cs,
                                        }).toString();
                                        https.get({
                                                host: "cache-a.oddcast.com",
                                                path: `/tts/gen.php?${q}`,
						headers: {
							Referer: "https://www.oddcast.com/",
							Origin: "https://www.oddcast.com/",
							"User-Agent":
								"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36",
						},
					},
					(r) => {
						var buffers = [];
						r.on("data", (d) => buffers.push(d));
						r.on("end", () => res(Buffer.concat(buffers)));
						r.on("error", rej);
					});
                                        break;
                                }

				case "acapela": {
					let acapelaArray = [];
					for (let c = 0; c < 15; c++) acapelaArray.push(~~(65 + Math.random() * 26));
					const email = `${String.fromCharCode.apply(null, acapelaArray)}@gmail.com`;

					let req = https.request(
						{
							hostname: "acapelavoices.acapela-group.com",
							path: "/index/getnonce",
							method: "POST",
							headers: {
								"Content-Type": "application/x-www-form-urlencoded",
							},
						},
						(r) => {
							let buffers = [];
							r.on("data", (b) => buffers.push(b));
							r.on("end", () => {
								const nonce = JSON.parse(Buffer.concat(buffers)).nonce;
								let req = https.request(
									{
										hostname: "acapela-group.com",
										port: "8443",
										path: "/Services/Synthesizer",
										method: "POST",
										headers: {
											"Content-Type": "application/x-www-form-urlencoded",
										},
									},
									(r) => {
										let buffers = [];
										r.on("data", (d) => buffers.push(d));
										r.on("end", () => {
											const html = Buffer.concat(buffers);
											const beg = html.indexOf("&snd_url=") + 9;
											const end = html.indexOf("&", beg);
											const sub = html.subarray(beg, end).toString();

											https
												.get(sub, (r) => {
                                                                                                        let buffers = [];
                                                                                                        r.on("data", (b) => buffers.push(b));
                                                                                                        r.on("end", () => 
                                                                                                                res(Buffer.concat(buffers)));
                                                                                                }).on("error", rej);
										});
										r.on("error", rej);
									}
								).on("error", rej);
								req.end(
									new URLSearchParams({
										req_voice: voice.arg,
										cl_pwd: "",
										cl_vers: "1-30",
										req_echo: "ON",
										cl_login: "AcapelaGroup",
										req_comment: `{"nonce":"${nonce}","user":"${email}"}`,
										req_text: text,
										cl_env: "ACAPELA_VOICES",
										prot_vers: 2,
										cl_app: "AcapelaGroup_WebDemo_Android",
									}).toString()
								);
							});
						}
					).on("error", rej);
					req.end(
						new URLSearchParams({
							json: `{"googleid":"${email}"`,
						}).toString()
					);
					break;
				}

				case "svox": {
					const q = new URLSearchParams({
						apikey: "e3a4477c01b482ea5acc6ed03b1f419f",
						action: "convert",
						format: "mp3",
						voice: voice.arg,
						speed: 0,
						text,
						version: "0.2.99",
					}).toString();

					https
						.get(`https://api.ispeech.org/api/rest?${q}`, (r) => {
                                                        let buffers = [];
                                                        r.on("data", (b) => buffers.push(b));
                                                        r.on("end", () =>res(Buffer.concat(buffers)));
                                                })
						.on("error", rej);
					break;
				}

				case "readloud": {
					const req = https.request(
						{
							hostname: "101.99.94.14",														
							path: voice.arg,
							method: "POST",
							headers: { 			
								Host: "gonutts.net",					
								"Content-Type": "application/x-www-form-urlencoded"
							}
						},
						(r) => {
							let buffers = [];
							r.on("data", (b) => buffers.push(b));
							r.on("end", () => {
								const html = Buffer.concat(buffers);
								const beg = html.indexOf("/tmp/");
								const end = html.indexOf("mp3", beg) + 3;
								const path = html.subarray(beg, end).toString();

								if (path.length > 0) {
									https.get({
										hostname: "101.99.94.14",	
										path: `/${path}`,
										headers: {
											Host: "gonutts.net"
										}
									}, (r) => {
                                                                                let buffers = [];
                                                                                r.on("data", (b) => buffers.push(b));
                                                                                r.on("end", () =>res(Buffer.concat(buffers)));
                                                                        }).on("error", rej);
								} else {
									return rej("Could not find voice clip file in response.");
								}
							});
						}
					);
					req.on("error", rej);
					req.end(
						new URLSearchParams({
							but1: text,
							butS: 0,
							butP: 0,
							butPauses: 0,
							but: "Submit",
						}).toString()
					);
					break;
				}
				case "cereproc": {
					const req = https.request(
						{
							hostname: "www.cereproc.com",
							path: "/themes/benchpress/livedemo.php",
							method: "POST",
							headers: {
								"content-type": "text/xml",
								"accept-encoding": "gzip, deflate, br",
								origin: "https://www.cereproc.com",
								referer: "https://www.cereproc.com/en/products/voices",
								"x-requested-with": "XMLHttpRequest",
								cookie: "Drupal.visitor.liveDemo=666",
							},
						},
						(r) => {
							var buffers = [];
							r.on("data", (d) => buffers.push(d));
							r.on("end", () => {
								const xml = String.fromCharCode.apply(null, brotli.decompress(Buffer.concat(buffers)));
								const beg = xml.indexOf("<url>") + 5;
								const end = xml.lastIndexOf("</url>");
								const loc = xml.substring(beg, end).toString();
								https.get(loc, (r) => {
                                                                        let buffers = [];
                                                                        r.on("data", (b) => buffers.push(b));
                                                                        r.on("end", () => res(Buffer.concat(buffers)));
                                                                }).on("error", rej);
							});
							r.on("error", rej);
						}
					);
					req.on("error", rej);
					req.end(
						`<speakExtended key='666'><voice>${voice.arg}</voice><text>${text}</text><audioFormat>mp3</audioFormat></speakExtended>`
					);
					break;
				}
				default: return rej("The voice you requested currently has no source available right now. Please try another voice.");
			}
		} catch (e) {
			return rej(e);
		}
	});
};