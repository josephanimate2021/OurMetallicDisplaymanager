const fs = require("fs");

module.exports = async (req, res, url) => {
        if (req.method != "GET" || !url.pathname.startsWith("/tmp")) return;
        const fileHeaderNames = {
                mp3: "audio/mp3",
                js: "text/js",
                json: "application/json"
        };
        const ext = url.pathname.substr(url.pathname.lastIndexOf(".") + 1);
        const filepath = url.pathname.substr(0, url.pathname.lastIndexOf("."));
        res.setHeader("Content-Type", fileHeaderNames[ext]);
        if (ext == "mp3") res.end(fs.readFileSync(filepath));
        else res.end(fs.readFileSync(url.pathname));
        return true;
}