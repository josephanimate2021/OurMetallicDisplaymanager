const http = require('http')
const tts = require("ttstool-api")
const port = 80 ;
const fs = require("fs");
const formidable = require("formidable");
const functions = [
        require("./controllers/tmp")
];
function loadPost(req) {
        return new Promise((res, rej) => {
                new formidable.IncomingForm().parse(req, async (e, f, files) => {
                        if (e) rej(e);
                        else res([f, files]);
                });
        });
}
const indeleteableFiles = {
        "lsp_logs": true,
        ".X11-unix": true,
}

fs.readdirSync('/tmp').forEach(file => { // deletes all of the temp files from the previous section
        if (!indeleteableFiles[file] && file.length != 32) fs.unlinkSync(`/tmp/${file}`);
})
  
// Create a server object:
http.createServer(async (req, res) => {
        res.statusCode = 404;
        const url = require("url").parse(req.url, true);
        let functionFound;
        try {
                for (const f of functions) {
                        functionFound = await f(req, res, url);
                        if (functionFound) res.statusCode = 200;
                }
                switch (req.method) {
                        case "GET": {
                                switch (url.pathname) {
                                        case "/": {
                                                res.statusCode = 200;
                                                res.setHeader("Content-Type", "text/html; charset=utf8");
                                                res.end(fs.readFileSync('./pages/tts-homepage.html'));
                                                break;
                                        } default: {
                                                if (fs.existsSync(`.${url.pathname}`)) {
                                                        res.statusCode = 200;
                                                        let content;
                                                        if (url.pathname.includes("/js/")) {
                                                                res.setHeader("Content-Type", "text/js");
                                                                content = fs.readFileSync(`.${url.pathname}`);
                                                        } else if (!url.pathname.includes("/css/")) {
                                                                res.setHeader("Content-Type", "text/html; charset=utf8");
                                                                content = fs.readFileSync(`.${url.pathname}`, 'utf8');
                                                        } else {
                                                                res.setHeader("Content-Type", "text/css");
                                                                content = fs.readFileSync(`.${url.pathname}`);
                                                        }
                                                        res.end(content);
                                                } else if (!functionFound) {
                                                        res.setHeader("Content-Type", "text/html; charset=utf8");
                                                        res.end(fs.readFileSync(`./pages/404.html`));
                                                }
                                        }
                                }
                                break;
                        } case "POST": {
                                switch (url.pathname) {
                                        case "/ajax/listAllVoices/": {
                                                res.statusCode = 200;
                                                res.setHeader("Content-Type", "application/json");
                                                res.end(JSON.stringify(await tts.getVoices()));
                                                break;
                                        } case "/ajax/convertText2Buffer/": {
                                                res.statusCode = 200;
                                                if (!url.query.voice) 
                                                        res.end(JSON.stringify({
                                                                fail: true,
                                                                error: "Please select a voice"
                                                        }));
                                                else if (url.query.text) {
                                                        const buffer = await tts.genMp3(url.query.voice, url.query.text);
                                                        res.end(JSON.stringify({
                                                                fail: false,
                                                                audioUrl: `data:audio/mpeg;base64,${buffer.toString("base64")}`
                                                        }));
                                                } else
                                                        res.end(JSON.stringify({
                                                                fail: true,
                                                                error: "Please enter some text"
                                                        }));
                                                break;
                                        } case "/ajax/convertBuffer2Text/": {
                                                res.statusCode = 200;
                                                const [data, files] = await loadPost(req);
                                                if (files.import) {
                                                        const filename = files.import.originalFilename.substr(
                                                                0, files.import.originalFilename.lastIndexOf(".")
                                                        ) + '.txt';
                                                        if (!files.import.mimetype.includes("audio")) {
                                                                fs.unlinkSync(files.import.filepath);
                                                                res.end(JSON.stringify({
                                                                        fail: true,
                                                                        error: 'Your file must be an audio file.'
                                                                }));
                                                        } else try {
                                                                const text = await tts.file2Text(files.import);
                                                                res.end(JSON.stringify({
                                                                        fail: false,
                                                                        text,
                                                                        filename,
                                                                        base64text: Buffer.from(text).toString("base64")
                                                                }));
                                                        } catch (e) {
                                                                console.log(e);
                                                                res.end(JSON.stringify({
                                                                        fail: true,
                                                                        error: e
                                                                }));
                                                        }
                                                } else
                                                        res.end(JSON.stringify({
                                                                fail: true,
                                                                error: 'Please select a file to upload.'
                                                        }));
                                                break;
                                        } default: break;
                                }
                                break;
                        } default: break;
                }
        } catch (e) {
                res.statusCode = 500;
                console.error(e);
                let content = fs.readFileSync(`./pages/500.html`, 'utf8');
                content = content.replace("SERVER_ERROR", e);
                res.end(content);
        }
        console.log(req.method, url.path, '-', res.statusCode);
})
// Set up the server so that it will listen on port 8080.
.listen(port, (error) => {
    // Checking for any error occurences while listening on port 8080.
    if (error) {
        console.log('Something went wrong', error);
    }
    // Else sent message of listening
    else {
        console.log('Server is listening on port ' + port);
    }
});