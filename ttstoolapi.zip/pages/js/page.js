class ModalWindow {
        constructor(content) {
                this.content = content;
        }
        show() {
                $(".shade").show();
                $(".modal").html(this.content).show();
        }
        hide() {
                $(".shade").hide();
                $(".modal").hide();
        }
}
$("#file").on("input", () => {
        const modalWindow = new ModalWindow(`
        <img src="https://th.bing.com/th/id/R.d6cd5151c04765d1992edfde14483068?rik=RRHcWY9w0PtzlA&pid=ImgRaw&r=0" height="100" width="100"/>
        <br>Uploading Your File...`);
        modalWindow.show();
        $("textarea").html('');
        $(".error").html('');
        let b = new FormData();
        b.append("import", document.getElementById("file").files[0]);
        switch (window.location.pathname) {
                case "/": break;
                default: {
                        $("#link").hide();
                        break;
                }
        }
        $.ajax({
                url: "/ajax/convertBuffer2Text/",
                method: "POST",
                data: b,
                processData: false,
                contentType: false,
                dataType: "json"
        }).done(d => {
                modalWindow.hide();
                fileUploaded(d);
        });
});