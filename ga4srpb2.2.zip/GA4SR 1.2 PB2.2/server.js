const env = Object.assign(process.env, require("./env"), require("./config"));
const fs = require('fs');
if (!fs.existsSync(env.SAVED_FOLDER)) fs.mkdirSync(env.SAVED_FOLDER);
const loadPost = require('./misc/post_body');
const loadPost2 = require('./data/post_body');
const fUtil = require("./misc/file");
const http = require("http");
const static = require("./static.js")
const wve = require("./waveform");
const chr = require("./character/redirect");
const ste = require("./store");
const pmc = require("./character/premade");
const chl = require("./character/load");
const chs = require("./character/save");
const cht = require("./character/thmb");
const mvu = require("./movie/upload");
const flg = require("./movie/flag");
const qkv = require("./movie/redirect");
const stl = require("./static/load");
const stp = require("./static/page");
const stc = require("./static/pagecc");
const lvp = require("./static/pagelvp");
const str = require("./starter/save");
const asl = require("./asset/load");
const asL = require("./asset/list");
const ast = require("./asset/thmb");
const mvl = require("./movie/load");
const mvL = require("./movie/list");
const mvm = require("./movie/meta");
const mvs = require("./movie/save");
const mvt = require("./movie/thmb");
const thL = require("./theme/list");
const thl = require("./theme/load");
const tsv = require("./tts/voices");
const tsl = require("./tts/load");
const url = require("url");
const formidable = require("formidable");

const functions = [mvL, stc, lvp, flg, ste, str, static, qkv, wve, pmc, asl, chl, thl, thL, chs, cht, asL, tsl, chr, ast, mvm, mvl, mvs, mvt, tsv, mvu, stp, stl];

// creates meta folders for a subtype if they don't exist
function createMetaFolders(mode) {
  try {
    if (!fs.existsSync('./meta')) fs.mkdirSync('./meta');
    if (!fs.existsSync(`./meta/${mode}`)) fs.mkdirSync(`./meta/${mode}`);
    if (!fs.existsSync(`./meta/${mode}/titles`)) fs.mkdirSync(`./meta/${mode}/titles`);
    return true;
  } catch (e) {
    console.log(e);
  }
}

function createTypeFolders(type) {
        const folder = `./${type}`;
        try {
                if (!fs.existsSync(folder)) fs.mkdirSync(folder);
        } catch (e) {
                console.log(e);
        }
}

module.exports = http.createServer((req, res) => {
        const parsedUrl = url.parse(req.url, true);
        try {
    // forces the lvm to load in some cases.
    // Other post requests trying this will be put here.
    if (req.method == "POST") switch (parsedUrl.path) {
      case "/api_v2/studio_preference/get": {
        res.statusCode = 200;
        res.end(
          JSON.stringify(
            {
              status: "ok", 
              data: [
                {
                  category: {
                    favorite: {
                      template: {
                        business: ["office"]
                      }
                    }, featured: {
                      template: {
                        business: []
                      }
                    }
                  }
                }
              ]
            }
          )
        );
        break;
      } case "/goapi/getUserFontList/": {
        res.statusCode = 200;
        res.end(JSON.stringify({status: "ok"}));
        break;
      } case "/api_v2/team/members": {
        res.statusCode = 200;
        res.end(JSON.stringify({status: "ok", data: {}}));
        break;// asset stuff
      } case "/goapi/deleteAsset/": {
              loadPost(req, res).then(([data]) =>  {
                      const file = data.assetId;
                      const [ aId, ext ] = file.split(".");
                      const [ id, subtype ] = aId.split("-");
                      var types = null;
                      switch (subtype) {
                              case "soundeffect":
                              case "bgmusic":
                              case "voiceover": {
                                      types = "sounds";
                                      break;
                              }
                      }
                      fs.unlinkSync(`./${types || subtype}/${file}`);
                      fs.unlinkSync(`./meta/${subtype}/titles/${aId}.txt`);
                      if (fs.existsSync(`./meta/${subtype}/${id}.json`)) 
                              fs.unlinkSync(`./meta/${subtype}/${id}.json`);
              });
              break;
      } case "/goapi/updateAsset/": {
              loadPost(req, res).then(([data]) => {
                      const file = data.assetId;
                      const [ aId, ext ] = file.split(".");
                      const [ id, subtype ] = aId.split("-");
                      fs.writeFileSync(`./meta/${subtype}/titles/${aId}.txt`, data.title);
              });
              break;
      } case "/api_v2/asset/delete/": {
              loadPost2(req, res).then(data => {
                      try {
                              const body = data.data;
                              const aId = body.id;
                              if (aId.startsWith("s")) return;
                              const [ name, ext ] = aId.split(".");
                              const [ id, subtype ] = name.split("-");
                              var types = null;
                              switch (subtype) {
                                      case "soundeffect":
                                      case "bgmusic":
                                      case "voiceover": {
                                              types = "sounds";
                                              break;
                                      }
                              }
                              fs.unlinkSync(`./${types || subtype}/${aId}`);
                              fs.unlinkSync(`./meta/${subtype}/titles/${name}.txt`);
                              if (fs.existsSync(`./meta/${subtype}/${id}.json`)) 
                                      fs.unlinkSync(`./meta/${subtype}/${id}.json`);
                              res.end("1");
                      } catch (e) {
                              console.log(e);
                      }
              });
              break;
      } case "/api_v2/asset/update/": {
              loadPost2(req, res).then(data => {
                      const body = data.data;
                      const aId = body.assetId;
                      if (aId.startsWith("s")) return;
                      const title = body.title;
                      const [ name, ext ] = aId.split(".");
                      const [ id, subtype ] = name.split("-");
                      fs.writeFileSync(`./meta/${subtype}/titles/${name}.txt`, title);
                      res.end(JSON.stringify({status: "ok"}));
              });
              break;
              /*
              Asset Importing

              if you want to know how this works, look at the code lol.
              */
      } 	case "/ajax/saveUserProp": {
                        new formidable.IncomingForm().parse(req, (e, f, files) => {
                                try {
                                        if (e) {
                                                res.end(JSON.stringify(
                                                        {
                                                                suc: false, 
                                                                msg: e
                                                        }
                                                ));
                                        } else if (!files) {
                                                res.end(
                                                        JSON.stringify({
                                                                suc: false,
                                                                msg: "Please choose a file to upload"
                                                        })
                                                );
                                        } else {
                                                const id = fUtil.generateId();
                                                const type = f.subtype == "soundeffect" ||
                                                        f.subtype == "voiceover" || f.subtype == "bgmusic"
                                                        ? "sound" : f.subtype;
                                                createMetaFolders(f.subtype);
                                                const file = files.file;
                                                const path = file.filepath;
                                                const name = file.originalFilename;
                                                const dot = name.lastIndexOf(".");
                                                const ext = name.substr(dot + 1);
                                                const newName = `${id}-${f.subtype}.${ext}`;
                                                const buffer = fs.readFileSync(path);
                                                var folder;
                                                if (type == "sound") folder = "./sounds";
                                                else folder = `./${type}`;
                                                createTypeFolders(folder);
                                                fs.writeFileSync(`${folder}/${newName}`, buffer);  
                                                fs.writeFileSync(`./meta/${
                                                        f.subtype
                                                }/titles/${id}-${f.subtype}.txt`, name);
                                                const info = {
                                                        suc: true,
                                                        // gives meta for the importer js file to read
                                                        id: newName,
                                                        asset_type: type,
                                                        filename: name,
                                                        asset_data: {
                                                                file: newName,
                                                                title: name,
                                                                subtype: f.subtype
                                                        }
                                                }
                                                switch (type) {
                                                        case "prop": {
                                                                info.thumbnail = `/assets/${newName}`;
                                                                info.asset_data.ptype = "placeable";
                                                                res.end(JSON.stringify(info));
                                                                break;
                                                        } case "sound": {
                                                                fUtil.duration(buffer).then(dur => {
                                                                        info.asset_data.duration = dur;
                                                                        info.duration = dur;
                                                                        info.asset_data.downloadtype = "progressive";
                                                                        fs.writeFileSync(`./meta/${
                                                                                f.subtype
                                                                        }/${id}.json`, JSON.stringify(info))
                                                                        res.end(JSON.stringify(info));
                                                                })
                                                                break;
                                                        } default: {
                                                                info.thumbnail = `/assets/${newName}`;
                                                                res.end(JSON.stringify(info));
                                                                break;
                                                        } 
                                                }
                                                fs.unlinkSync(path);

                                        }
                                } catch (e) {
                                        console.log(e);
                                        res.end(JSON.stringify({
                                                suc: false, 
                                                msg: "File Upload Failed. Please check your command prompt for more details."
                                        }));
                                }
                        });
                        return true;
                }
    }
		const found = functions.find((f) => f(req, res, parsedUrl));
		if (!found) res.statusCode = 404;
    console.log(req.method, parsedUrl.path, '-', res.statusCode);
    // this is supposed to be an error handler for server.js. Please leave that alone.
	} catch (x) {
		res.statusCode = 500;
    console.log(x);
    console.log(req.method, parsedUrl.path, '-', res.statusCode);
    res.end("This website has ran into a server error. Please try reloading this site in a few minutes.");
  }
}).listen(env.PORT || env.SERVER_PORT, console.log("GoAnimate For Schools Remastered Has Started Sucessfully"));
