const chars = require("../character/main");
const fUtil = require("../misc/file");
const movie = require("../movie/main");
const nodezip = require("node-zip");
const fs = require("fs");
const header = process.env.XML_HEADER;

module.exports = {
        genRandonString(length) {
                var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@$%*';
                var charLength = chars.length;
                var result = '';
                for ( var i = 0; i < length; i++ ) {
                        result += chars.charAt(Math.floor(Math.random() * charLength));
                }
                return result;
        },
        settings(id, ip) {
                const baseDb = {
                        tutorial: !fs.existsSync(`./tutorial-${id}.txt`), 
                        themelist_type: fs.existsSync(`./themelist-${id}.txt`) ? fs.readFileSync(`./themelist-${id}.txt`, 'utf8') : "gotest_themelist", 
                        waveform: !fs.existsSync(`./waveform-${id}.txt`),
                        watermark: fs.existsSync(`./watermark-${id}.txt`) ? fs.readFileSync(`./watermark-${id}.txt`, 'utf8') : "g4s",
                        wide: fs.existsSync(`./wide-${id}.txt`) ? "1" : "0",
                        ip_address: ip,
                        mode: fs.existsSync(`./mode-${id}.txt`),
                        moreAssets: fs.existsSync(`./moreAssets-${id}.txt`) ? false : true,
                        ccps_videomaker_tryout: fs.existsSync(`./ccps_videomaker_tryout-${id}.txt`),
                        original_lvm_tryout: fs.existsSync(`./original_lvm_tryout-${id}.txt`),
                        lvm_type: fs.existsSync(`./lvm-${id}.txt`) ? fs.readFileSync(`./lvm-${id}.txt`, 'utf8') : "gowrapper_themelist"
                };
                if (baseDb.themelist_type != "allthemes_themelist") baseDb.moreAssets = true;
                return baseDb;
        },
        load(id, mode) {
                return fs.readFileSync(`./${mode}/${id}`)
	},
        subtype2words(subtype) {
                switch (subtype) {
                        case "sound": return "sounds";
                        case "prop": return "props";
                        case "bg": return "backgrounds";
                }
        },
        async loadSound(data) {
                const aId = data.assetId;
                // while this is designed to load sound, this is also designed for the legacy importer.
                if (!aId.includes(".mp3")) {
                        const subfile = aId.split("-")[1];
                        const subtype = subfile.split(".")[0];
                        return fs.readFileSync(`./${subtype}/${aId}`)
                } else return fs.readFileSync(`./sounds/${aId}`);
        },
        saveSound(buffer, mode, ext) {
                return new Promise(res => {
                        const id = this.genRandonString(12);
                        if (!fs.existsSync('./sounds')) fs.mkdirSync('./sounds');
                        fs.writeFileSync(`./sounds/${id}-${mode}.${ext}`, buffer);
                        res(`${id}-${mode}.${ext}`);
                });
        },
	list(mode, subtype) {
                const table = [];
                var folder = `./${mode}`;
                if (subtype == "video") folder = `./videos`;
                else if (mode == "sound") folder = `./sounds`;
                if (mode == "starter") {
                        var ids = fUtil.getValidFileIndicies("starter-", ".xml");
                        for (const i in ids) {
                                var id = `s-${ids[i]}`;
                                const title = fs.readFileSync(`./meta/starter/titles/${id}.txt`, 'utf8');
                                const tag = fs.readFileSync(`./meta/starter/tags/${id}.txt`, 'utf8');
                                table.push({ id: id, name: title, tag: tag });
                        }
                } else {
                        if (!fs.existsSync(folder)) fs.mkdirSync(folder);
                        fs.readdirSync(folder).forEach(file => {
                                if (file.includes("-tts.")) return table;
                                if (mode == "sound") {
                                        const [ id, sound ] = file.split("-");
                                        const subtype = sound.split(".")[0];
                                        const meta = require(`../meta/${subtype}/${id}.json`);
                                        const title = fs.readFileSync(`./meta/${subtype}/titles/${
                                                file.slice(0, -4)
                                        }.txt`);
                                        table.push({
                                                id: file, 
                                                name: title, 
                                                differentBuffer: true, 
                                                mode: mode,
                                                subtype: subtype, 
                                                duration: meta.duration
                                        });
                                } else {
                                        const name = fs.readFileSync(
                                                `./meta/${mode}/titles/${file.slice(0, -4)}.txt`, 'utf8')
                                        table.push({
                                                id: file, 
                                                name: name, 
                                                differentBuffer: false, 
                                                mode: mode
                                        });
                                }
                        });
                }
                return table;
	},
        meta(id, mode, ext) {
                var subtype, type;
                if (mode == "bg" && mode == "prop") subtype = 0;
                else subtype = mode;
                if (mode == "voiceover" && mode == "soundeffect" && mode == "bgmusic") type = "sound";
                const title = fs.readFileSync(`./meta/${mode}/titles/${id}.txt`);
                const info = {
                        id: id + '.' + ext,
                        tags: "",
                        type: type || mode,
                        subtype: subtype,
                        title: title,
                        themeId: "ugc"
                };
                if (type == "sound") 
                        info.duration = fUtil.duration(fs.readFileSync(`./sounds/${id}-${mode}.${ext}`))
                return info;
        },
        async meta2Xml(data, makeZip = false, makeJson = false, noFiles = false) {
                var xmlString, files;
                switch (data.type) {
                        case "char": {
                                if (!noFiles) {
                                        files = await this.chars(data.themeId);
                                        xmlString = `${header}<ugc more="0">${
                                                files.map(v => `<char id="${
                                                        v.id
                                                }" name="Character" cc_theme_id="${
                                                        v.theme
                                                }" thumbnail_url="/char_thumbs/${
                                                        v.id
                                                }.png" copyable="Y"><tags/></char>`).join("")
                                        }</ugc>`;
                                } else xmlString = `<char id="${
                                        data.id
                                }" name="Character" cc_theme_id="${
                                        data.theme
                                }" thumbnail_url="/char_thumbs/${
                                        data.id
                                }.png" copyable="Y"><tags/></char>`;
                                break;
                        } case "bg": {
                                if (!noFiles) {
                                        files = this.list("bg");
                                        xmlString = `${header}<ugc more="0">${
                                                files.map(v => `<background subtype="0" id="${
                                                        v.id
                                                }" name="${
                                                        v.name
                                                }" enable="Y" ${
                                                        makeJson ? `asset_url="/assets/${
                                                                v.id
                                                        }"` : ""
                                                }/>`).join("")
                                        }</ugc>`;
                                } else xmlString = `<background subtype="0" id="${
                                        data.id
                                }" name="${data.name}" enable="Y" ${
                                        makeJson ? `asset_url="/asset?folder=bg&file=${
                                                data.id
                                        }"` : ""
                                }/>`;
                                break;
                        } case "sound": {
                                if (!noFiles) {
                                        files = this.list("sound");
                                        xmlString = `${header}<ugc more="0">${
                                                files.map(v => `<sound subtype="${
                                                        v.subtype
                                                }" id="${v.id}" name="${v.name}" enable="Y" duration="${
                                                        v.duration
                                                }" downloadtype="progressive"/>`).join("")
                                        }</ugc>`;
                                } else xmlString = `<sound subtype="${
                                        data.subtype
                                }" id="${data.id}" name="${data.name}" enable="Y" duration="${
                                        data.duration
                                }" downloadtype="progressive"/>`;
                                break;
                        } case "movie": {
                                if (!noFiles) {
                                        files = this.list("starter");
                                        xmlString = `${header}<ugc more="0">${
                                                files.map((v) => `<movie id="${
                                                        v.id
                                                }" enc_asset_id="${v.id}" path="/_SAVED/${
                                                        v.id
                                                }" numScene="1" title="${
                                                        v.name
                                                }" thumbnail_url="/movie_thumbs/${v.id}.png"><tags>${
                                                        v.tag
                                                }</tags></movie>`).join("")
                                        }</ugc>`;
                                } else xmlString = `<movie id="${
                                        data.id
                                }" enc_asset_id="${data.id}" path="/_SAVED/${
                                        data.id
                                }" numScene="1" title="${
                                        data.name
                                }" thumbnail_url="/movie_thumbs/${data.id}.png"><tags></tags></movie>`;
                                break;
                        } case "prop": {
                                if (!noFiles) {
                                        if (data.subtype != "video") {
                                                files = this.list("prop");
                                                xmlString = `${header}<ugc more="0">${

                                                        files.map((v) => `<prop subtype="0" id="${v.id}" enc_asset_id="${v.id}" name="${v.name}" enable="Y" placeable="1" facing="left" width="0" height="0" asset_url="/assets/${v.id}"/>`).join("")
                                                }</ugc>`;
                                        } else {
                                                files = this.list("prop", "video");
                                                xmlString = `${header}<ugc more="0">${files.map(v => `<prop subtype="video" id="${v.id}" enc_asset_id="${v.id}" name="${v.name}" enable="Y" placeable="1" facing="left" width="${v.width}" height="${v.height}" asset_url="/assets/${v.id}" thumbnail_url="/assets/${v.id.slice(0, -3) + "png"}"/>`).join("")}</ugc>`;
                                        }
                                } else xmlString = `<prop subtype="${data.subtype}" id="${data.id}" enc_asset_id="${data.id}" name="${data.name}" enable="Y" placeable="1" facing="left" width="${data.width}" height="${data.height}" asset_url="/assets/${data.id}" ${data.thmbXml || ""}/>`;
                                break;
                        } default: {
                                if (!noFiles) xmlString = `${header}<ugc more="0"></ugc>`;
                                else xmlString = ``;
                        }
                }
                if (makeZip) {
                        const zip = nodezip.create();
                        fUtil.addToZip(zip, "desc.xml", Buffer.from(xmlString));
                        for (const file of files) {
                                switch (file.mode) {
                                        case "movie": break;
                                        default: {
                                                var buffer = this.load(file.id, file.mode);
                                                if (!file.differentBuffer) buffer = this.load(file.id, file.mode);
                                                fUtil.addToZip(zip, `${file.mode}/${file.id}`, buffer);
                                        }
                                }
                        }
                        return await zip.zip();
                } else if (makeJson) return JSON.stringify(
                        {
                                status: "ok", 
                                data: { 
                                        xml: xmlString 
                                }
                        });
                else if (noFiles) return xmlString;
                else return Buffer.from(xmlString);
        },
	chars(theme) {
                if (!fs.existsSync('./chars')) fs.mkdirSync('./chars');
		return new Promise(async (res, rej) => {
			switch (theme) {
				case "custom":
					theme = "family";
					break;
				case "action":
				case "animal":
				case "space":
				case "vietnam":
					theme = "cc2";
					break;
			}
			var table = [];
			fs.readdirSync('./chars').forEach(async file => {
                                const [ id, ext ] = file.split(".");
                                if (ext == "png") return;
                                if (theme == await chars.getTheme(id)) table.unshift({ 
                                        theme: theme, 
                                        id: id 
                                });
			});
			res(table);
		});
	},
};
