const loadPost = require("../misc/post_body");
const movie = require("../movie/main");
const http = require("http");

/**
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 * @param {import("url").UrlWithParsedQuery} url
 * @returns {boolean}
 */
module.exports = function (req, res, url) {
	if (req.method != "POST" || url.path != "/goapi/saveTemplate/") return;
  loadPost(req, res).then(([data]) => {
		var body = Buffer.from(data.body_zip, "base64");
		var thumb = Buffer.from(data.thumbnail, "base64");
    movie.save(body, thumb, true).then((nId) => res.end("0" + nId));
	});
	return true;
};
