const fs = require('fs');

module.exports = function (req, res, url) {
	var path = url.pathname;
	if (req.method != "GET" || !path.startsWith("/static")) return;
        // prevents css from turning into text/plain witch causes problems.
        if (path.includes(".css")) res.setHeader("Content-Type", "text/css")
        res.end(fs.readFileSync('.' + path))
	return true;
};
