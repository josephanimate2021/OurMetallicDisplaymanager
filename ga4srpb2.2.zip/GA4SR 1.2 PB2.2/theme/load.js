const loadPost = require("../misc/post_body");
const folder = process.env.THEME_FOLDER;
const get = require("../misc/get");
const fUtil = require("../misc/file");
const http = require("http");
const nodezip = require("node-zip")

/**
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 * @param {import("url").UrlWithParsedQuery} url
 * @returns {boolean}
 */
module.exports = function (req, res, url, _settings, _user) {
  if (req.method != "POST" || url.path != "/goapi/getTheme/") return;
  loadPost(req, res).then(([data]) => {
          var theme = data.themeId;
          res.setHeader("Content-Type", "application/zip");
          if (data.ctc == "domo" || data.ctc == "cn") {
                  get(`https://ourmetallicdisplaymanager.joseph-animate.repl.co/static/store/${theme}/theme.xml`).then(b => {
                          fUtil.zipOnGet(b, "theme.xml").then(b => res.end(b));
                  });
          } else
                  fUtil.makeZip(
                          `${folder}/${theme}.xml`, "theme.xml"
                  ).then((b) => res.end(b)).catch(e => console.log(e));
  });
	return true;
};
