const get = require('./misc/get');

module.exports = function (req, res, url) {
	var path = url.pathname;
	if (req.method != "GET" || !path.startsWith("/store")) return;
	if (path.includes(".swf")) res.setHeader("Content-Type", "application/x-shockwave-flash");
	get(`https://bluepeacocks.github.io/NewGA4SRCloudfrontServer${path}`).then(buff => res.end(buff));
	return true;
};
