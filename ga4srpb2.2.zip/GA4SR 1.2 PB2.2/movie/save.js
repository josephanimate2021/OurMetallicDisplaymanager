const loadPost = require("../misc/post_body");
const movie = require("./main");
const http = require("http");

/**
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 * @param {import("url").UrlWithParsedQuery} url
 * @returns {boolean}
 */
module.exports = function (req, res, url) {
	if (req.method != "POST" || url.pathname != "/goapi/saveMovie/") return;
        loadPost(req, res).then(([data]) => {
                //console.log(data);
                try {
                        const trigAutosave = data.is_triggered_by_autosave;
                        var body = Buffer.from(data.body_zip, "base64");
                        movie.getStockThumb(data.tray).then(buffer => {
                                if (trigAutosave) {
                                        thumb = buffer;
                                        large = buffer;
                                } else {
                                        thumb = Buffer.from(data.thumbnail, "base64");
                                        large = Buffer.from(data.thumbnail_large, "base64");
                                }
                                movie.save(body, thumb, false, large, data.movieId || data.presaveId).then((nId) => 
                                        res.end(0 + nId)).catch(e => {
                                        console.log(e);
                                        res.end("1");
                                });
                        }).catch(e => {
                                console.log(e);
                                res.end("1");
                        });
                } catch (e) {
                        console.log(e);
                        res.end("1");
                }
        });
	return true;
};
