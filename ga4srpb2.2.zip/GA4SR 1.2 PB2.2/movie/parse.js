const get = require("../misc/get");
const fs = require("fs");
const nodezip = require("node-zip");
const jszip = require("jszip");
const mp3Duration = require("mp3-duration");
const xmldoc = require("xmldoc");
const char = require("../character/main");
const fUtil = require("../misc/file");
const { subtle } = require("crypto");
const source = process.env.CLIENT_URL;
const store = process.env.STORE_URL;
const header = process.env.XML_HEADER;

function name2Font(font) {
	switch (font) {
		case "Blambot Casual":
			return "FontFileCasual";
		case "BadaBoom BB":
			return "FontFileBoom";
		case "Entrails BB":
			return "FontFileEntrails";
		case "Tokyo Robot Intl BB":
			return "FontFileTokyo";
		case "Accidental Presidency":
			return "FontFileAccidental";
		case "Budmo Jiggler":
			return "FontFileBJiggler";
		case "Budmo Jigglish":
			return "FontFileBJigglish";
		case "Existence Light":
			return "FontFileExistence";
		case "HeartlandRegular":
			return "FontFileHeartland";
		case "Honey Script":
			return "FontFileHoney";
		case "I hate Comic Sans":
			return "FontFileIHate";
		case "loco tv":
			return "FontFileLocotv";
		case "Mail Ray Stuff":
			return "FontFileMailRay";
		case "Mia\'s Scribblings ~":
			return "FontFileMia";
		case "Coming Soon":
			return "FontFileCSoon";
		case "Lilita One":
			return "FontFileLOne";
		case "Telex Regular":
			return "FontFileTelex";
		case "":
		case null:
			return '';
		default:
			return `FontFile${font.replace(/\s/g, '')}`;
	}
}

/**
 * @param {ReadableStream} readStream 
 * @returns {Promise<Buffer>}
 */
function buffer2Duration(buffer) {
	return new Promise((res, rej) => {
		mp3Duration(buffer, (e, d) => {
			if (e) rej(e);
			res(d * 1e3);
		});
	});
}
function stream2Buffer(readStream) {
	return new Promise((res, rej) => {
		let buffers = [];
		readStream.on("data", (c) => buffers.push(c)).on("end", () => res(Buffer.concat(buffers))).on("error", rej);
	});
}

module.exports = {
	/**
	 * Parses a movie XML by adding files to a ZIP.
	 * @param {Buffer} xmlBuffer 
	 * @param {Buffer | null} thumbBuffer 
	 * @returns {Promise<Buffer>}
	 */
	async pack(xmlBuffer, thumbBuffer = null, largeBuffer = null) {
		if (xmlBuffer.length == 0) throw null;
	
		const zip = nodezip.create();
		const themes = { common: true };
		var ugc = `${header}<theme id="ugc" name="ugc">`;
		fUtil.addToZip(zip, "movie.xml", xmlBuffer);
	
		// this is common in this file
		async function basicParse(file, type, subtype) {
			const pieces = file.split(".");
			const themeId = pieces[0];

			// add the extension to the last key
			const ext = pieces.pop();
			pieces[pieces.length - 1] += "." + ext;
			// add the type to the filename
			pieces.splice(1, 0, type);

			const filename = pieces.join(".");
			if (themeId == "ugc") {
				const id = pieces[2];
				try {
                    subtype ||= pieces[1];
					const buffer = fs.readFileSync(`./${subtype}/${id}`);
                    const title = fs.readFileSync(`./meta/${subtype}/titles/${id.split(".")[0]}.txt`, 'utf8');
					// add asset meta
                    switch (type) {
                        case "prop": {
                            if (subtype == "video") {
                                ugc += `<prop subtype="video" id="${id}" enc_asset_id="${id}" name="${title}" enable="Y" placeable="1" facing="left" width="640" height="360" asset_url="/assets/${id}" thumbnail_url="/assets/${id.slice(0, -3) + "png"}"/>`
                                pieces[2] = pieces[2].slice(0, -3) + "png";
                                const filename = pieces.join(".")
                                const buffer = asset.load(pieces[2]);
                                fUtil.addToZip(zip, filename, buffer);
                            } else ugc += `<prop subtype="0" id="${id}" enc_asset_id="${id}" name="${title}" enable="Y" placeable="1" facing="left" width="0" height="0" asset_url="/assets/${id}"/>`
                            break;
                        } case "bg": {
                            ugc += `<background subtype="0" id="${id}" enc_asset_id="${id}" name="${title}" enable="Y" asset_url="/assets/${id}"/>`
                            break;
                        } case "sound": {
                            ugc += `<sound subtype="${subtype}" id="${id}" enc_asset_id="${id}" name="${title}" enable="Y" duration="${await buffer2Duration(buffer)}" downloadtype="progressive"/>`
                            break;
                        }
                    }
					// and add the file
					fUtil.addToZip(zip, filename, buffer);

				} catch (e) {
					console.error(`WARNING: Couldn't find asset ${id}:`, e);
					return;
				}
			} else {
				const filepath = `${store}/${pieces.join("/")}`;

				// add the file to the zip
				fUtil.addToZip(zip, filename, await get(filepath));
			}

			themes[themeId] = true;
		}
	
		// begin parsing the movie xml
		const film = new xmldoc.XmlDocument(xmlBuffer);
		for (const eI in film.children) {
			const elem = film.children[eI];
	
			switch (elem.name) {
				case "sound": {
					const file = elem.childNamed("sfile")?.val;
					if (!file) continue;
					
					await basicParse(file, elem.name)
					break;
				}
	
				case "scene": {
					for (const e2I in elem.children) {
						const elem2 = elem.children[e2I];
	
						let tag = elem2.name;
						// change the tag to the one in the store folder
						if (tag == "effectAsset") tag = "effect";
	
						switch (tag) {
							case "durationSetting":
							case "trans":
								break;
							case "bg":
							case "effect":
							case "prop": {
								const file = elem2.childNamed("file")?.val;
								if (!file) continue;
								
								await basicParse(file, tag, elem2.attr.subtype);
								break;
							}
							
							case "char": {
								let file = elem2.childNamed("action")?.val;
								if (!file) continue;
								const pieces = file.split(".");
								const themeId = pieces[0];
	
								const ext = pieces.pop();
								pieces[pieces.length - 1] += "." + ext;
								pieces.splice(1, 0, elem2.name);
		
								if (themeId == "ugc") {
									// remove the action from the array
									pieces.splice(3, 1);
	
									const id = pieces[2];
									try {
										const buffer = await char.load(id);
										const filename = pieces.join(".");
	
										ugc += `<char id="${id}" enc_asset_id="${id}" name=""Untitled"" cc_theme_id="${await char.getTheme(buffer)}" thumbnail_url="/assets/${id}.png" copyable="Y"><tags></tags></char>`;
										fUtil.addToZip(zip, filename + ".xml", buffer);
									} catch (e) {
										console.error(`WARNING: ${id}:`, e);
										continue;
									}
								} else {
									const filepath = `${store}/${pieces.join("/")}`;
									const filename = pieces.join(".");
	
									fUtil.addToZip(zip, filename, await get(filepath));
								}
	
								for (const e3I in elem2.children) {
									const elem3 = elem2.children[e3I];
									if (!elem3.children) continue;
	
									// add props and head stuff
									file = elem3.childNamed("file")?.val;
									if (!file) continue;
									const pieces2 = file.split(".");
	
									// headgears and handhelds
									if (elem3.name != "head") await basicParse(file, "prop");
									else { // heads
										if (pieces2[0] == "ugc") continue;
										pieces2.pop(), pieces2.splice(1, 0, "char");
										const filepath = `${store}/${pieces2.join("/")}.swf`;
	
										pieces2.splice(1, 1, "prop");
										const filename = `${pieces2.join(".")}.swf`;
										fUtil.addToZip(zip, filename, await get(filepath));
									}
	
									themes[pieces2[0]] = true;
								}
	
								themes[themeId] = true;
								break;
							}
	
							case 'bubbleAsset': {
								const bubble = elem2.childNamed("bubble");
								const text = bubble.childNamed("text");
	
								// arial doesn't need to be added
								if (text.attr.font == "Arial") continue;
	
								const filename = `${name2Font(text.attr.font)}.swf`;
								const filepath = `${source}/go/font/${filename}`;
								fUtil.addToZip(zip, filename, await get(filepath));
								break;
							}
						}
					}
					break;
				}
			}
		}
	
		if (themes.family) {
			delete themes.family;
			themes.custom = true;
		}
	
		if (themes.cc2) {
			delete themes.cc2;
			themes.action = true;
		}
		const themeKs = Object.keys(themes);

		themeKs.forEach(t => {
			if (t == "ugc") return;
			const file = fs.readFileSync(`./themelist/${t}.xml`);
			fUtil.addToZip(zip, `${t}.xml`, file);
		});
		fUtil.addToZip(zip, "themelist.xml", Buffer.from(`${header}<themes>${themeKs.map((t) => `<theme>${t}</theme>`).join("")}</themes>`));
		console.log(ugc + "</theme>");
		fUtil.addToZip(zip, "ugc.xml", Buffer.from(ugc + "</theme>"));
		if (thumbBuffer) fUtil.addToZip(zip, "thumbnail.png", thumbBuffer);
		if (largeBuffer) fUtil.addToZip(zip, "movie.png", largeBuffer);
		return await zip.zip();
	},

	/**
	 * @summary Unpacks a movie using jszip
	 * @param {Buffer} movieZip
	 * @param {string} path
	 */
	async unpackSingle(movieZip, path) {
		try {
		  const jszipInstance = new jszip();
		  const result = await jszipInstance.loadAsync(movieZip);
		  const keys = Object.keys(result.files);
		  for (let key of keys) {
			const item = result.files[key];
			fs.writeFileSync(path, Buffer.from(await item.async("arraybuffer")));
		  }
		} catch (e) {
		  console.log(e);
		}
	},
	/**
     * Unpacks a movie zip containing mutiple files
     * @param {Buffer} body 
     * @returns {Promise<Buffer>}
     */
	async unpackMutiple(body) {
		const zip = nodezip.unzip(body);
		const readStream = zip["movie.xml"].toReadStream();
		const buffer = await stream2Buffer(readStream);
		if (!zip["thumbnail.png"]) return {xmlBuffer: buffer, thumbBuffer: await get(process.env.THUMB_BASE_URL + `/278841975.jpg`)};
		const readStream2 = zip["thumbnail.png"].toReadStream();
		let thumbBuffer = await stream2Buffer(readStream2);
		if (zip["movie.png"]) {
            const readStream3 = zip["movie.png"].toReadStream();
            let largeBuffer = await stream2Buffer(readStream3);
            return { xmlBuffer: buffer, thumbBuffer: thumbBuffer, largeBuffer: largeBuffer };
		}
		return { xmlBuffer: buffer, thumbBuffer: thumbBuffer };
	},
	/**
     *
     * @param {Buffer} xml 
     * @param {number} id 
     */
	unpackXml(xml, id) {
		get(process.env.THUMB_BASE_URL + `/278841975.jpg`).then(v => {
			fs.writeFileSync(fUtil.getFileIndex('thumb-', '.png', id), v);
		})
		fs.writeFileSync(fUtil.getFileIndex('movie-', '.xml', id), xml);
	},
	unpackCharXml(xml, id) {
        get(process.env.THUMB_BASE_URL + `/120503625.png`).then(v => {
            fs.writeFileSync(fUtil.getFileIndex('char-', '.png', id), v);
        })
        fs.writeFileSync(fUtil.getFileIndex('char-', '.xml', id), xml);
    },
};