const movie = require("./main");
const loadPost = require("../misc/post_body");
const fs = require("fs");
const fUtil = require("../misc/file");
const { genRandonString } = require("../asset/main");
const base = Buffer.alloc(1, 0);
/**
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 * @param {import("url").UrlWithParsedQuery} url
 * @returns {boolean}
 */
module.exports = function (req, res, url) {
	switch (req.method) {
		case "GET": {
			const match = req.url.match(/\/movies\/([^.]+)(?:\.(zip|xml))?$/);
			if (!match) return;

			var id = match[1];
      var ext = match[2];
      if (ext != "zip") res.end("The file needs to be a zip format in order to download your movie.")
      else {
        res.setHeader("Content-Type", "application/zip");
        // gets a movie's zip file (helpful for downloading movies to use on wrapper offline.)
        async function loadMovie() {
          return await movie.loadZip(id);
        }
        loadMovie().then(b => {
                res.setHeader("Content-Type", "application/zip");
                res.end(b);
        }).catch(e => console.log(e));
        // downloading movies via xml file can be something that redrawn online can do.
      }
			return true;
		}

		case "POST": {
      switch (url.pathname) {
        case "/ajax/getNewMovieId/": {
          res.end(`m-${fUtil.getNextFileId("movie-", ".xml")}`)
          break;
        } case "/goapi/getMovie/": {
          async function loadMovie() {
                  return Buffer.concat([base, await movie.loadZip(url.query.movieId)]);
          }
          loadMovie().then(b => {
                  res.setHeader("Content-Type", "application/zip");
                  res.end(b); 
          }).catch(e => {
                  console.log(e);
                  res.end("1");
          });
          return true;
          // searches for a movie by title or tag
        } case "/ajax/searchMovies": {
          loadPost(req, res).then(([data]) => {
            const search = data.search;
            res.statusCode = 302;
            res.setHeader("Location", `/html/list.html?search_query=${search}`);
            res.end();
          });
          return true;
          // gets a watermark by user or default settings
        } case "/goapi/getMovieInfo/": {
          res.setHeader("Content-Type", "application/xml");
          res.end(`<watermarks><watermark style="g4s"/></watermarks>`)
          return true;
          // deletes a movie along with it's meta
        } case "/ajax/movie/delete": {
          try {
            const id = url.query.id;
            const i = id.indexOf("-");
            const suffix = id.substr(i + 1);
            const path = fUtil.getFileIndex("movie-", ".xml", suffix);
            const thumbPath = fUtil.getFileIndex("thumb-", ".png", suffix);
            const largePath = fUtil.getFileIndex("movie-", ".png", suffix);
            const usrPath = fUtil.getFileIndex("user-", ".json", suffix);
            const hiddenPath = fUtil.getFileIndex("hidden-movie-", ".txt", suffix);
            fs.existsSync(hiddenPath) ? fs.unlinkSync(hiddenPath) : "";
            fs.unlinkSync(path);
            fs.unlinkSync(thumbPath);
            fs.unlinkSync(largePath);
            fs.unlinkSync(usrPath);
            if (url.query.from != "domoanimate") res.end(JSON.stringify({status: "ok"}));
            else res.end(JSON.stringify({code: "0", url: "/static/domo/list.html"}));
          } catch (e) {
            res.end(JSON.stringify({status: "error"}));
          }
          return true;
        }
      }
		}
		default:
			return;
	}
};
