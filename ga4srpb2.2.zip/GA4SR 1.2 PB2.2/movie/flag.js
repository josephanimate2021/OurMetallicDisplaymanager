const fs = require("fs");
const fUtil = require("../misc/file");

module.exports = function(req, res, url) {
        if (req.method != "GET" || !url.pathname.startsWith("/ajax/flagMovie")) return;
        try {
                const mId = url.pathname.substr(url.pathname.lastIndexOf("/") + 1);
                const number = mId.split("-")[1];
                const filepath = fUtil.getFileIndex("movie-", ".xml", number);
                const filename = filepath.substr(filepath.lastIndexOf("/") + 1).slice(0, -3) + "txt";
                console.log(mId, number, filepath, filename);
                if (!fs.existsSync("./meta/flaggedMovies")) fs.mkdirSync("./meta/flaggedMovies");
                fs.writeFileSync("./meta/flaggedMovies/" + filename, `This movie has been reported as inappropriate. if you are a staff member who is seeing this message, please delete the movie along with it's files with the same id immediately!. the files should be located in ${process.env.SAVED_FOLDER}.`);
                res.end(JSON.stringify({
                        success: true
                }));
        } catch (e) {
                res.end(JSON.stringify({
                        success: false
                }))
                console.log(e);
        }
        return true;
}