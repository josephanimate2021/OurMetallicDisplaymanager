const fUtil = require("../misc/file");
const stuff = require("./info");
const http = require("http");

function toAttrString(table) {
	return typeof table == "object"
		? Object.keys(table)
				.filter((key) => table[key] !== null)
				.map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(table[key])}`)
				.join("&")
		: table.replace(/"/g, '\\"');
}
function toParamString(table) {
	return Object.keys(table)
		.map((key) => `<param name="${key}" value="${toAttrString(table[key])}">`)
		.join(" ");
}
function toObjectString(attrs, params) {
	return `<object ${Object.keys(attrs)
		.map((key) => `${key}="${attrs[key].replace(/"/g, '\\"')}"`)
		.join(" ")}>${toParamString(params)}</object>`;
}

/**
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 * @param {import("url").UrlWithParsedQuery} url
 * @returns {boolean}
 */
module.exports = function (req, res, url) {
	if (req.method != "GET" || !url.pathname.startsWith("/character_creator")) return;
    if (url.pathname.includes("char-default.png")) {
        res.end();
        return true;
    }
    var tId = url.pathname.substr(url.pathname.lastIndexOf("/") + 1).split("?")[0];
    const query = url.query;
    var originalId
    if (url.pathname.includes("copy")) {
        originalId = url.pathname.substr(url.pathname.lastIndexOf("/") + 1).split("?")[0];
        tId = query.themeId;
    }
    const isBrowser = url.pathname.includes("new_char") || url.pathname.includes("copy") ? "" : "_browser";
    title = "Make a Character - GoAnimate for Schools Remastered";
	attrs = {
		data: `/animation/414827163ad4eb60/cc${isBrowser}.swf`,
		type: "application/x-shockwave-flash",
		id: "char_creator",
		width: "960",
		height: !url.pathname.includes("new_char") && !url.pathname.includes("copy") ? "1200" : "600",
	};
	params = {
		flashvars: {
			apiserver: "http://localhost:4343/",
			storePath: "/store/3a981f5cb2739137/<store>",
            clientThemePath: "/static/ad44370a650793d9/<client_theme>",
			original_asset_id: originalId || "",
			themeId: tId || "family",
			ut: 60,
			appCode: "go",
			page: "",
            bs: query.type || "",
			siteId: "school",
			m_mode: "school",
			isLogin: "Y",
			isEmbed: 0,
			ctc: "go",
			tlang: "en_US",
			lid: 13,
		},
		allowScriptAccess: "always",
		movie: `/animation/414827163ad4eb60/cc${isBrowser}.swf`,
	};
	res.setHeader("Content-Type", "text/html; charset=UTF-8");
	Object.assign(params.flashvars, query);
	res.end(`
	<head>
    <script>document.title='${title}',flashvars=${JSON.stringify(
	params.flashvars
	)}</script><link rel="stylesheet" type="text/css" href="/html/css/common_combined.css.gz.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:400,700">
    <link rel="stylesheet" href="/html/css/cc.css.gz.css">
    <script src="/html/school/js/common_combined.js.gz.js"></script>
    <script>function characterSaved(){window.location = '/movies'}</script>
    </head>
    <body>
    <nav class="navbar site-nav" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
            <a class="navbar-brand" href="/movies" title="GoAnimate for Schools Remastered">
                <img src="/html/img/logo4s.png" alt="GoAnimate For Schools Remastered">
            </a>
        </div>
    
        <ul class="nav site-nav-alert-nav hidden-xs">
            <li>
                <a href="/messages" title="Messages"><span class="glyphicon glyphicon-envelope"></span><span class="count"></span></a>
            </li>
            <li>
                <a href="/notifications" title="Notifications"><span class="glyphicon glyphicon-bell"></span><span class="count"></span></a>
            </li>
        </ul>
        <div class="collapse navbar-collapse navbar-ex1-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" href="#" data-toggle="dropdown">Your Account <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="/dashboard">Dashboard</a></li>
                        <li><a href="/movies">Your Videos</a></li>
                        <li class="divider"></li>
                        <li><a href="/account">Account Settings</a></li>
                        <li><a href="/html/watermark.html">Your Watermarks</a></li>
                        <li class="divider"></li>
                        <li><a class="logout-link" href="/logoff">Logout</a></li>
                    </ul>
                </li><li class="dropdown">
                    <a class="dropdown-toggle" href="#" data-toggle="dropdown">Explore <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="/students">Students</a></li>
                        <li><a href="/teachers">Teachers</a></li>
                        <li><a href="/videos">Videos</a></li>
                        <li><a href="/public_faq">FAQ</a></li>
                    </ul>
                </li>
                <li>
                <a class="hidden-sm hidden-md hidden-lg" href="/create">Make a Video</a>
                <span class="site-nav-btn hidden-xs"><a class="btn btn-green" href="/create">Make a Video</a></span>
                </li>
            </ul>
        </div>
    </div>
    </nav>
    <div class="container container-cc">
      <ul class="breadcrumb">
                <li><a href="/create">Make a video</a></li>
                <li${!url.pathname.includes("new_char") && !url.pathname.includes("copy") ? ' class="active"' : `><a href="/character_creator/${tId}"`}">Your Characters${url.pathname.includes("new_char") || url.pathname.includes("copy") ? '</a>' : ''}</li>
                ${url.pathname.includes("new_char") || url.pathname.includes("copy") ? '<li class="active">Create a new character</li>' : ''}
            </ul>
    
            ${!url.pathname.includes("new_char") && !url.pathname.includes("copy") ? "<p>Browse characters already available in your theme and use them as a starting point to create new custom characters.</p>" : ""}
    
    <div id="${!url.pathname.includes("new_char") && !url.pathname.includes("copy") ? 'ccbrowser-container' : 'char_creator_client'}" align="center">
    ${toObjectString(attrs, params)}
    </div>
    </div>
    <footer class="site-footer hidden-print">
    <div class="container">
        <div class="row site-footer-nav">
            <div class="col-sm-3">
                <div class="site-footer-nav-col">
                    <h5>About GoAnimate</h5>
                    <ul class="list-unstyled">
                        <li><a href="https://discord.gg/bb8xXaWPv3">Who We Are</a></li>
                        <li><a href="https://discord.gg/bb8xXaWPv3">Contact Us</a></li>
                        <li><a href="https://discord.gg/bb8xXaWPv3">Blog</a></li>
                    </ul>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="site-footer-nav-col">
                    <h5>GoAnimate Solutions</h5>
                    <ul class="list-unstyled">
                        <li><a href="https://itsredacted.000webhostapp.com/" target="_blank">GoAnimate for Schools</a></li>
                        <li class="hidden-xs">&nbsp;</li>
                        <li class="hidden-xs">&nbsp;</li>
                        <li class="hidden-xs">&nbsp;</li>
                    </ul>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="site-footer-nav-col">
                    <h5>Getting Help</h5>
                    <ul class="list-unstyled">
                        <li><a href="https://discord.gg/bb8xXaWPv3">Help Center</a></li>
                        <li class="hidden-xs">&nbsp;</li>
                        <li class="hidden-xs">&nbsp;</li>
                    </ul>
                </div>
            </div>
        </div>
        <hr>

        <div class="row site-footer-copyright">
            <div class="col-sm-6">
                <div class="site-footer-socials-container">
                    Follow us on:
                    <ul class="site-footer-socials clearfix">
                        <li><a class="youtube" href="https://www.youtube.com/channel/UCiEYUXgWlGQqYfxyMhYGWRQ">YouTube</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="pull-right">
                    <img src="/html/img/logo_amazon.png" alt="AWS Partner Network">
                    &nbsp;&nbsp;&nbsp;
                    GoAnimate © 2022
                </div>
            </div>
        </div>

    </div>
</footer>
	</body>`
	);
	return true;
};
