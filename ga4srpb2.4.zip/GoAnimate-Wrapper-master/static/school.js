const get = require("../misc/get");
const http = require("http");

/**
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 * @param {import("url").UrlWithParsedQuery} url
 * @returns {boolean}
 */
module.exports = function (req, res, url) {
	var path = url.pathname;
	if (req.method != "GET" || !path.startsWith("/animation/cce25167cb1d3404") && !path.startsWith("/store/4e75f501cfbf51e3") && !path.startsWith("/static/642cd772aad8e952")) return;
	if (path.includes("swf")) res.setHeader("Content-Type", "application/x-shockware-flash")
	get(`https://josephanimate2021.github.io${path}`).then((v) => res.end(v));
	return true;
};