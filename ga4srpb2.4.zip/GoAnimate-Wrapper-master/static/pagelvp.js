const fUtil = require("../misc/file");
const stuff = require("./info");
const http = require("http");
const movie = require("../movie/main");

function toAttrString(table) {
	return typeof table == "object"
		? Object.keys(table)
				.filter((key) => table[key] !== null)
				.map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(table[key])}`)
				.join("&")
		: table.replace(/"/g, '\\"');
}
function toParamString(table) {
	return Object.keys(table)
		.map((key) => `<param name="${key}" value="${toAttrString(table[key])}">`)
		.join(" ");
}
function toObjectString(attrs, params) {
	return `<object id="obj" ${Object.keys(attrs)
		.map((key) => `${key}="${attrs[key].replace(/"/g, '\\"')}"`)
		.join(" ")}>${toParamString(params)}</object>`;
}

/**
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 * @param {import("url").UrlWithParsedQuery} url
 * @returns {boolean}
 */
module.exports = function (req, res, url) {
	if (req.method != "GET" || !url.pathname.startsWith("/movie/")) return;
    const mId = url.pathname.substr(url.pathname.lastIndexOf("/") + 1);
    const query = url.query;
    title = "Video Player - GoAnimate For Schools Remastered";
	attrs = {
		data: process.env.SWF_URL + "/player.swf",
		type: "application/x-shockwave-flash",
		width: "100%",
		height: "100%",
	};
	params = {
		flashvars: {
			apiserver: "http://localhost:4343/",
			storePath: process.env.STORE_URL + "/<store>",
            movieId: mId || "",
			ut: 60,
			thumbnailURL: `http://localhost:4343/movie_thumbs/${mId}.png`,
			isEmbed: 1,
			autostart: mId.startsWith("e-") ? 1 : 0,
			isWide: 1,
			clientThemePath: process.env.CLIENT_URL + "/<client_theme>",
		},
		allowScriptAccess: "always",
		allowFullScreen: "true",
	};
	res.setHeader("Content-Type", "text/html; charset=UTF-8");
	Object.assign(params.flashvars, query);
	res.end(`<html>
	<head>
	<link rel="stylesheet" type="text/css" href="/html/css/common_combined.css.gz.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:400,700">
	<link rel="stylesheet" href="/html/css/movie.css.gz.css">
	<script src="/html/school/js/common_combined.js.gz.js"></script>
	<script>document.title='${title}',meta=${JSON.stringify(movie.metaWithoutPromise(mId))}</script>
	<script>
	const date = meta.date.split("T")[0];
	const usDate = \`\${date.split("-")[1]}/\${date.split("-")[2]}/\${date.split("-")[0]}\`;
	</script>
	</head>
	<body style="margin:0px">
		<nav class="navbar site-nav" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-ex1-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				<a class="navbar-brand" href="/dashboard/videos" title="GoAnimate for Schools Remastered">
					<img src="/html/img/logo4s.png" alt="GoAnimate For Schools Remastered">
				</a>
			</div>
	
			<ul class="nav site-nav-alert-nav hidden-xs">
				<li>
					<a href="/messages" title="Messages"><span class="glyphicon glyphicon-envelope"></span><span class="count"></span></a>
				</li>
				<li>
					<a href="/notifications" title="Notifications"><span class="glyphicon glyphicon-bell"></span><span class="count"></span></a>
				</li>
			</ul>
			<div class="collapse navbar-collapse navbar-ex1-collapse">
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown">
						<a class="dropdown-toggle" href="#" data-toggle="dropdown">Your Account <span class="caret"></span></a>
						<ul class="dropdown-menu">
							<li><a href="/dashboard">Dashboard</a></li>
							<li><a href="/movies">Your Videos</a></li>
							<li class="divider"></li>
							<li><a href="/account">Account Settings</a></li>
							<li><a href="/html/watermark.html">Your Watermarks</a></li>
							<li class="divider"></li>
							<li><a class="logout-link" href="/logoff">Logout</a></li>
						</ul>
					</li><li class="dropdown">
						<a class="dropdown-toggle" href="#" data-toggle="dropdown">Explore <span class="caret"></span></a>
						<ul class="dropdown-menu">
							<li><a href="/students">Students</a></li>
							<li><a href="/teachers">Teachers</a></li>
							<li><a href="/dashboard/videos">Videos</a></li>
							<li class="divider"></li>
							<li><a href="https://discord.gg/bb8xXaWPv3">Educator Experiences</a></li>
							<li><a href="/public_faq">FAQ</a></li>
						</ul>
					</li>
					<li>
						<a class="hidden-sm hidden-md hidden-lg" href="/c/create">Make a Video</a>
						<span class="site-nav-btn hidden-xs"><a class="btn btn-green" href="/c/create">Make a Video</a></span>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	<div id="video-page"><script>document.write(\`
	<div class="video-top">
		<div class="container">
			<div class="row">
				<div class="col-sm-6 video-left">
					<div class="status-container">
						<div class="vthumb-container">
							<div class="vthumb">
								<div class="vthumb-clip"><div class="vthumb-clip-inner"><span class="valign"></span><img src="/movie_thumbs/\${meta.id}.png" alt="\${meta.title}"></div></div>
							</div>
						</div>
					</div>
					<div class="video-top-content clearfix">
						<div class="pull-left video-info">
							<h1>\${meta.title}</h1>
							By <a title="You">You</a>                     </div>
						<div class="video-top-status">
								</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>\`)</script>
	<div class="video-main">
	<div class="container">
			<div class="video-main-content">
				<div class="video-header clearfix noshow">
				</div>
	
				<div class="video-content">
					<div class="player-container">
	<meta name="medium" content="video">
	<div style="position:relative">
		<div id="playerdiv" align="center" style="width:620px;height:349px;">
	${toObjectString(attrs, params)}
	</div>
		</div>
	
					</div>
				</div>
				
	<script>
	$('.video-actions').toggle($('.video-actions').find('.btn').length > 0);
	</script>
	
	
				
			</div>
			<div class="video-main-aside" id="player-aside"></div>
	
	</div>
	</div><script>document.write(\`
	<div class="container main-container">
		<div class="row">
			<div class="col-md-8">
				<ul class="nav nav-tabs">
					<li class="active"><a href="#video-info" data-toggle="tab">More Info</a></li>
				</ul>
	
				<div class="tab-content">
					<div class="tab-pane active" id="video-info">
						<p class="inside">Published on: \${usDate}</p>
						<p></p>
					</div>
				</div>
			</div>
			<div class="col-md-4 aside video-aside">
	
				<div></div><br>
	
			</div>
		</div>
	</div>\`)</script>
	</div>
	<footer class="site-footer hidden-print">
    <div class="container">
        <div class="row site-footer-nav">
            <div class="col-sm-3">
                <div class="site-footer-nav-col">
                    <h5>About GoAnimate</h5>
                    <ul class="list-unstyled">
                        <li><a href="https://discord.gg/bb8xXaWPv3">Who We Are</a></li>
                        <li><a href="https://discord.gg/bb8xXaWPv3">Contact Us</a></li>
                        <li><a href="https://discord.gg/bb8xXaWPv3">Blog</a></li>
                    </ul>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="site-footer-nav-col">
                    <h5>GoAnimate Solutions</h5>
                    <ul class="list-unstyled">
                        <li><a href="https://itsredacted.000webhostapp.com/" target="_blank">GoAnimate for Schools</a></li>
                        <li class="hidden-xs">&nbsp;</li>
                        <li class="hidden-xs">&nbsp;</li>
                        <li class="hidden-xs">&nbsp;</li>
                    </ul>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="site-footer-nav-col">
                    <h5>Getting Help</h5>
                    <ul class="list-unstyled">
                        <li><a href="https://discord.gg/bb8xXaWPv3">Help Center</a></li>
                        <li class="hidden-xs">&nbsp;</li>
                        <li class="hidden-xs">&nbsp;</li>
                    </ul>
                </div>
            </div>
        </div>
        <hr>

        <div class="row site-footer-copyright">
            <div class="col-sm-6">
                <div class="site-footer-socials-container">
                    Follow us on:
                    <ul class="site-footer-socials clearfix">
                        <li><a class="youtube" href="https://www.youtube.com/channel/UCiEYUXgWlGQqYfxyMhYGWRQ">YouTube</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="pull-right">
                    <img src="/html/img/logo_amazon.png" alt="AWS Partner Network">
                    &nbsp;&nbsp;&nbsp;
                    GoAnimate © 2022
                </div>
            </div>
        </div>

    </div>
</footer>
	</body></html>`
	);
	return true;
};