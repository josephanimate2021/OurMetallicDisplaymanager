var mp3Duration = require("mp3-duration");
var char = require("../character/main");
const caché = require("../asset/cache");
const jszip = require("jszip");
var source = process.env.CLIENT_URL;
var header = process.env.XML_HEADER;
var get = require("../misc/get");
var fUtil = require("../misc/file");
var nodezip = require("node-zip");
var store = process.env.STORE_URL;
var xmldoc = require("xmldoc");
var fs = require("fs");

function name2Font(font) {
	switch (font) {
		case "Blambot Casual":
			return "FontFileCasual";
		case "BadaBoom BB":
			return "FontFileBoom";
		case "Entrails BB":
			return "FontFileEntrails";
		case "Tokyo Robot Intl BB":
			return "FontFileTokyo";
		case "Accidental Presidency":
			return "FontFileAccidental";
		case "BodoniXT":
			return "FontFileBodoniXT";
		case "Budmo Jiggler":
			return "FontFileBJiggler";
		case "Budmo Jigglish":
			return "FontFileBJigglish";
		case "Existence Light":
			return "FontFileExistence";
		case "HeartlandRegular":
			return "FontFileHeartland";
		case "Honey Script":
			return "FontFileHoney";
		case "I hate Comic Sans":
			return "FontFileIHate";
		case "Impact Label":
			return "FontFileImpactLabel";
		case "loco tv":
			return "FontFileLocotv";
		case "Mail Ray Stuff":
			return "FontFileMailRay";
		case "Mia's Scribblings ~":
			return "FontFileMia";
		case "Shanghai":
			return "FontFileShanghai";
		case "Comic Book":
			return "FontFileComicBook";
		case "Wood Stamp":
			return "FontFileWoodStamp";
		case "Brawler":
			return "FontFileBrawler";
		case "Coming Soon":
			return "FontFileCSoon";
		case "Glegoo":
			return "FontFileGlegoo";
		case "Lilita One":
			return "FontFileLOne";
		case "Telex Regular":
			return "FontFileTelex";
		case "Claire Hand":
			return "FontFileClaireHand";
		case "Oswald":
			return "FontFileOswald";
		case "Poiret One":
			return "FontFilePoiretOne";
		case "Raleway":
			return "FontFileRaleway";
		case "Bangers":
			return "FontFileBangers";
		case "Creepster":
			return "FontFileCreepster";
		case "BlackoutMidnight":
			return "FontFileBlackoutMidnight";
		case "BlackoutSunrise":
			return "FontFileBlackoutSunrise";
		case "Junction":
			return "FontFileJunction";
		case "LeagueGothic":
			return "FontFileLeagueGothic";
		case "LeagueSpartan":
			return "FontFileLeagueSpartan";
		case "OstrichSansMedium":
			return "FontFileOstrichSansMedium";
		case "Prociono":
			return "FontFileProciono";
		case "Lato":
			return "FontFileLato";
		case "Alegreya Sans SC":
			return "FontFileAlegreyaSansSC";
		case "Barrio":
			return "FontFileBarrio";
		case "Bungee Inline":
			return "FontFileBungeeInline";
		case "Bungee Shade":
			return "FontFileBungeeShade";
		case "Gochi Hand":
			return "FontFileGochiHand";
		case "IM Fell English SC":
			return "FontFileIMFellEnglishSC";
		case "Josefin":
			return "FontFileJosefin";
		case "Kaushan":
			return "FontFileKaushan";
		case "Lobster":
			return "FontFileLobster";
		case "Montserrat":
			return "FontFileMontserrat";
		case "Mouse Memoirs":
			return "FontFileMouseMemoirs";
		case "Patrick Hand":
			return "FontFilePatrickHand";
		case "Permanent Marker":
			return "FontFilePermanentMarker";
		case "Satisfy":
			return "FontFileSatisfy";
		case "Sriracha":
			return "FontFileSriracha";
		case "Teko":
			return "FontFileTeko";
		case "Vidaloka":
			return "FontFileVidaloka";
		case "":
		case null:
			return "";
		default:
			return `FontFile${font}`;
	}
}

/**
 * @param {ReadableStream} readStream 
 * @returns {Promise<Buffer>}
 */
function buffer2Duration(buffer) {
	return new Promise((res, rej) => {
		mp3Duration(buffer, (e, d) => {
			if (e) rej(e);
			res(d * 1e3);
		});
	});
}
function stream2Buffer(readStream) {
	return new Promise((res, rej) => {
		let buffers = [];
		readStream.on("data", (c) => buffers.push(c)).on("end", () => res(Buffer.concat(buffers))).on("error", rej);
	});
}


module.exports = {
	/**
	 * @summary Reads an XML buffer, decodes the elements, and returns a PK stream the LVM can parse.
	 * @param {Buffer} xmlBuffer
	 * @param {string} mId
	 * @returns {Promise<{zipBuf:Buffer,caché:{[aId:string]:Buffer}}>}
	 */
	async pack(xmlBuffer, mId) {
		if (xmlBuffer.length == 0) throw null;
		var zip = nodezip.create();
		var themes = { common: true };
		var ugcString = `${header}<theme id="ugc" name="ugc">`;
		// this is common in this file
		async function basicParse(file, type, subtype) {
			const pieces = file.split(".");
			const themeId = pieces[0];

			// add the extension to the last key
			const ext = pieces.pop();
			pieces[pieces.length - 1] += "." + ext;
			// add the type to the filename
			pieces.splice(1, 0, type);

			const filename = pieces.join(".");
			if (themeId == "ugc") {
				const id = pieces[2];
				try {
                    subtype ||= pieces[1];
					if (subtype == "sound") subtype = id.split("-")[1].split(".")[0];
					const folder =  subtype == "voiceover" || subtype == "soundeffect" || subtype == "bgmusic"
					 ? "./sounds" : `./${subtype}`;
					var buffer;
					if (id.includes("tts")) buffer = caché.load(mId, id);
					else buffer = fs.readFileSync(`${folder}/${id}`);
                    const title = fs.readFileSync(`./meta/${subtype}/titles/${id.split(".")[0]}.txt`, 'utf8');
					// add asset meta
                    switch (type) {
                        case "prop": {
                            if (subtype == "video") {
                                ugcString += `<prop subtype="video" id="${id}" enc_asset_id="${id}" name="${title}" enable="Y" placeable="1" facing="left" width="640" height="360" asset_url="/assets/${id}" thumbnail_url="/assets/${id.slice(0, -3) + "png"}"/>`
                                pieces[2] = pieces[2].slice(0, -3) + "png";
                                const filename = pieces.join(".")
                                const buffer = asset.load(pieces[2]);
                                fUtil.addToZip(zip, filename, buffer);
                            } else ugcString += `<prop subtype="0" id="${id}" enc_asset_id="${id}" name="${title}" enable="Y" placeable="1" facing="left" width="0" height="0" asset_url="/assets/${id}"/>`
                            break;
                        } case "bg": {
                            ugcString += `<background subtype="0" id="${id}" enc_asset_id="${id}" name="${title}" enable="Y" asset_url="/assets/${id}"/>`
                            break;
                        } case "sound": {
                            ugcString += `<sound subtype="${subtype}" id="${id}" enc_asset_id="${id}" name="${title}" enable="Y" duration="${await buffer2Duration(buffer)}" downloadtype="progressive"/>`
                            break;
                        }
                    }
					// and add the file
					fUtil.addToZip(zip, filename, buffer);

				} catch (e) {
					console.error(`WARNING: Couldn't find asset ${id}:`, e);
					return;
				}
			} else {
				const filepath = `${store}/${pieces.join("/")}`;

				// add the file to the zip
				fUtil.addToZip(zip, filename, await get(filepath));
			}

			themes[themeId] = true;
		}
		fUtil.addToZip(zip, "movie.xml", xmlBuffer);
		var xml = new xmldoc.XmlDocument(xmlBuffer);

		var elements = xml.children;
		for (var eK in elements) {
			var element = elements[eK];
			switch (element.name) {
				case "scene": {
					for (var pK in element.children) {
						var piece = element.children[pK];
						var data = piece.name;
						if (data == "effectAsset") {
							data = "effect";
						}

						switch (data) {
							case "durationSetting":
							case "trans":
								break;
							case "bg":
							case "effect":
							case "prop": {
								const file = piece.childNamed("file")?.val;
								if (!file) continue;
									
								await basicParse(file, data, piece.attr.subtype);
								break;
							}
							/* broken but displays chars fine.
							case "char": {
								var val = piece.childNamed("action").val;
								var slices = val.split(".");

								var theme, ccTheme, fileName, buffer;
								switch (slices[slices.length - 1]) {
									case "xml": {
										theme = slices[0];
										var id = slices[1];
										fileName = `${theme}.char.${id}.xml`;
										var prefix = id.substr(0, id.indexOf("-"));

										switch (prefix) {
											case "C":
												break;
											case "c":
											default:
												try {
													ccTheme = await char.getTheme(id);
												} catch (e) {
													ccTheme = "family";
												}
												break;
										}
										break;
									}
									case "swf": {
										var ch = slices[1];
										var model = slices[2];
										ccTheme = theme = slices[0];
										var url = `${store}/${theme}/char/${ch}/${model}.swf`;
										fileName = `${theme}.char.${ch}.${model}.swf`;
										buffer = await get(url);
										break;
									}
								}

								var ugcCharSubs = [];
								for (let ptK in piece.children) {
									var part = piece.children[ptK];
									if (!part.children) continue;

									var file = part.childNamed("file");
									if (!file) continue;
									var fName = file ? file.val : part.val;
									var slicesP = fName.split(".");
									if (slicesP[0] == "ugc") {
										switch (part.name) {
											case "head":
												ugcCharSubs[slicesP[3]] = "facial";
												break;
											case "action":
												ugcCharSubs[slicesP[2]] = "action";
												break;
											default:
												continue;
										}
									} else if (slicesP.length > 1) {
										var urlF, fileF;
										switch (part.name) {
											case "head":
												urlF = "char";
												fileF = "prop";
												break;
											case "prop":
												urlF = "prop";
												fileF = "prop";
												break;
											default:
												continue;
										}

										slicesP.pop(), slicesP.splice(1, 0, urlF);
										var urlP = `${store}/${slicesP.join("/")}.swf`;

										slicesP.splice(1, 1, fileF);
										var fileP = `${slicesP.join(".")}.swf`;
										if (!zip[fileP]) {
											fUtil.addToZip(zip, fileP, await get(urlP));
										}
									}
								}

								themes[theme] = true;
								if (buffer) fUtil.addToZip(zip, fileName, buffer);
								if (ugcData[id]) {
									Object.assign(ugcData[id].subs, ugcCharSubs);
								} else if (id) {
									ugcData[id] = {
										type: "char",
										subs: ugcCharSubs,
										theme: ccTheme,
									};
								}
								break;
							}*/
							case "char": { // working and allows you to change emotions on video edit.
								let file = piece.childNamed("action")?.val;
								if (!file) continue;
								const pieces = file.split(".");
								const themeId = pieces[0];

								const ext = pieces.pop();
								pieces[pieces.length - 1] += "." + ext;
								pieces.splice(1, 0, piece.name);
		
								if (themeId == "ugc") {
									// remove the action from the array
									pieces.splice(3, 1);

									const id = pieces[2];
									try {
										const buffer = await char.load(id);
										const filename = pieces.join(".");

										ugcString += `<char id="${id}" enc_asset_id="${id}" name="Untitled" cc_theme_id="${await char.getTheme(id)}" thumbnail_url="char_default.png" copyable="Y"><tags/></char>`;
										fUtil.addToZip(zip, filename + ".xml", buffer);
									} catch (e) {
										console.error(`WARNING: Couldn't find asset ${id}:`, e);
										continue;
									}
								} else {
									const filepath = `${store}/${pieces.join("/")}`;
									const filename = pieces.join(".");

									fUtil.addToZip(zip, filename, await get(filepath));
								}

								for (const e3I in piece.children) {
									const elem3 = piece.children[e3I];
									if (!elem3.children) continue;

									// add props and head stuff
									file = elem3.childNamed("file")?.val;
									if (!file) continue;
									const pieces2 = file.split(".");

									// headgears and handhelds
									if (elem3.name != "head") {
										await basicParse(file, "prop");
									} else { // heads
										if (pieces2[0] == "ugc") continue;
										pieces2.pop(), pieces2.splice(1, 0, "char");
										const filepath = `${store}/${pieces2.join("/")}.swf`;

										pieces2.splice(1, 1, "prop");
										const filename = `${pieces2.join(".")}.swf`;
										fUtil.addToZip(zip, filename, await get(filepath));
									}

									themes[pieces2[0]] = true;
								}

								themes[themeId] = true;
								break;
							}
							case "bubbleAsset": {
								var bubble = piece.childNamed("bubble");
								var text = bubble.childNamed("text");
								var font = `${name2Font(text.attr.font)}.swf`;
								var fontSrc = `${source}/go/font/${font}`;
								if (!zip[font]) {
									fUtil.addToZip(zip, font, await get(fontSrc));
								}
								break;
							}
						}
					}
					break;
				}

				case "sound": {
					const file = element.childNamed("sfile")?.val;
					if (!file) continue;
					
					await basicParse(file, element.name)
					break;
				}
			}
		}

		if (themes.family) {
			delete themes.family;
			themes.custom = true;
		}

		if (themes.cc2) {
			delete themes.cc2;
			themes.action = true;
		}

		for (const t in themes) {
			switch (t) {
				case "common":
					break;
				case "ugc":
				default:
					continue;
			}
			var file = await get(`${store}/${t}/theme.xml`);
			fUtil.addToZip(zip, `${t}.xml`, file);
		}
		/* for chars that would have been broken if used.
		for (const id in ugcData) {
			var data = ugcData[id];
			switch (data.type) {
				case "char": {
					if (data.theme === undefined) {
						console.warn("Character theme undefined.");
						continue;
					}

					var subs = "";
					for (var subId in data.subs) subs += `<${data.subs[subId]} id="${subId}.xml" enable="Y"/>`;
					ugcString += `<char id="${id}"cc_theme_id="${data.theme}"><tags/>${subs}</char>`;
					try {
						var buffer = await char.load(id);
						fUtil.addToZip(zip, `ugc.${data.type}.${id}.xml`, buffer);
					} catch (e) {}
				}
				case "sound":
					continue;
			}
			var buffer = assetBuffers[id];
			fUtil.addToZip(zip, `ugc.${data.type}.${id}`, buffer);
		}*/

		const themeKs = Object.keys(themes);

		fUtil.addToZip(zip, "themelist.xml", Buffer.from(`${header}<themes>${themeKs.map((t) => `<theme>${t}</theme>`).join("")}</themes>`));
		console.log(ugcString + `</theme>`);
		fUtil.addToZip(zip, "ugc.xml", Buffer.from(ugcString + `</theme>`));
		return await zip.zip();
	},
	/**
	 * @summary Unpacks a movie using jszip
	 * @param {Buffer} movieZip
	 * @param {string} path
	 */
	async unpackSingle(movieZip, path) {
		try {
		  const jszipInstance = new jszip();
		  const result = await jszipInstance.loadAsync(movieZip);
		  const keys = Object.keys(result.files);
		  for (let key of keys) {
			const item = result.files[key];
			fs.writeFileSync(path, Buffer.from(await item.async("arraybuffer")));
		  }
		} catch (e) {
		  console.log(e);
		}
	},
	/**
     * Unpacks a movie zip containing mutiple files
     * @param {Buffer} body 
     * @returns {Promise<Buffer>}
     */
	async unpackMutiple(body) {
		const zip = nodezip.unzip(body);
		const readStream = zip["movie.xml"].toReadStream();
		const buffer = await stream2Buffer(readStream);
		if (!zip["thumbnail.png"]) return {xmlBuffer: buffer, thumbBuffer: await get(process.env.THUMB_BASE_URL + `/278841975.jpg`)};
		const readStream2 = zip["thumbnail.png"].toReadStream();
		let thumbBuffer = await stream2Buffer(readStream2);
		if (zip["movie.png"]) {
            const readStream3 = zip["movie.png"].toReadStream();
            let largeBuffer = await stream2Buffer(readStream3);
            return { xmlBuffer: buffer, thumbBuffer: thumbBuffer, largeBuffer: largeBuffer };
		}
		return { xmlBuffer: buffer, thumbBuffer: thumbBuffer };
	},
	/**
     *
     * @param {Buffer} xml 
     * @param {number} id 
     */
	unpackXml(xml, id) {
		get(process.env.THUMB_BASE_URL + `/278841975.jpg`).then(v => {
			fs.writeFileSync(fUtil.getFileIndex('thumb-', '.png', id), v);
		})
		fs.writeFileSync(fUtil.getFileIndex('movie-', '.xml', id), xml);
	},
	async unpackCharXml(xml) {
		const id = fUtil.getNextFileId("char-", ".xml");
		get(process.env.THUMB_BASE_URL + `/120503625.png`).then(v => {
			fs.writeFileSync(fUtil.getFileIndex('char-', '.png', id), v);
		})
		fs.writeFileSync(fUtil.getFileIndex('char-', '.xml', id), xml);
		const tId = await char.getTheme(`c-${id}`);
		return {
			id,
			tId
		}
    }
};