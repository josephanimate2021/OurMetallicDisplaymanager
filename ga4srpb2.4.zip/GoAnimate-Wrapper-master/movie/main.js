/**
 * Movie Saving
 * 
 * on sidenote, this LVM project uses an older database i created myself a long time ago. i will most likely be turning all of this into a json file soon.
 */
const caché = require("../asset/cache");
const exFolder = process.env.EXAMPLE_FOLDER;
const fUtil = require("../misc/file");
const parse = require("./parse");
const fs = require("fs");
function p(type, ext, suffix) {
	return fUtil.getFileIndex(`${type}-`, `.${ext}`, suffix)
}
function createMetaFolders(mode) {
	try {
		const dirs = ['./meta', `./meta/${mode}`, `./meta/${mode}/titles`, `./meta/${mode}/tags`];
		for (const dir of dirs) {
			if (!fs.existsSync(dir)) fs.mkdirSync(dir);
		}
	} catch (e) {
	  console.log(e);
	}
}
module.exports = {
	/**
	 * @summary Generates a thumb using a sushi image for autosaving something.
	 * @returns {Buffer}
	 */
	getRandomThumb() {
		return fs.readFileSync(`./html/img/SUSHI.jfif`);
	},
	/**
	 * @summary Saves a movie
	 * @returns {Promise<string>}
	 */
	save(movieZip, thumb, mId, isStarter = false) {
		if (isStarter) {
			mId ||= `s-${fUtil.getNextFileId("starter-", ".xml")}`;
			createMetaFolders("starter");
		}
		else mId ||= `m-${fUtil.getNextFileId("movie-", ".xml")}`;
		// Saves the thumbnail of the respective video.
		if (thumb) {
			var n = Number.parseInt(mId.substr(2));
			var thumbFile = fUtil.getFileIndex("thumb-", ".png", n);
			if (isStarter) thumbFile = fUtil.getFileIndex("starter-", ".png", n);
			fs.writeFileSync(thumbFile, thumb);
		}
		return new Promise(async (res, rej) => {
			try {
				const [ prefix, suffix ] = mId.split("-");
				switch (prefix) {
					case "m": {
						var path = p("movie", "xml", suffix);
						await parse.unpackSingle(movieZip, path);
						res(mId);
						break;
					} case "s": {
						var path = p("starter", "xml", suffix);
						await parse.unpackSingle(movieZip, path);
						this.meta(mId).then(m => {
							fs.writeFileSync(`./meta/starter/tags/${m.id}.txt`, m.tag);
							fs.writeFileSync(`./meta/starter/titles/${m.id}.txt`, m.title);
							res(m.id);
						});
						break;
					} case "e": {
						var path = `${exFolder}/${mId.split("-")[1]}.zip`;
						const v = await parse.unpackMutiple(movieZip);
						const buffer = await parse.pack(v.xmlBuffer, mId);
						fs.writeFileSync(path, buffer)
						res(mId);
						break;
					}
				}
			} catch (e) {
				rej(e);
			}
		});
	},
	async loadZip(mId) {
		const [ prefix, suffix ] = mId.split("-");
		var filepath, thumbpath;
		switch (prefix) {
			case "m": {
				filepath = fUtil.getFileIndex("movie-", ".xml", suffix);
				thumbpath = fUtil.getFileIndex("thumb-", ".png", suffix);
				break;
			} case "s": {
				filepath = fUtil.getFileIndex("starter-", ".xml", suffix);
				thumbpath = fUtil.getFileIndex("starter-", ".png", suffix);
				break;
			} case "e": {
				caché.clearTable(mId);
				let data = fs.readFileSync(`${exFolder}/${suffix}.zip`);
				return data.subarray(data.indexOf(80));
			}
		}
		try {
            if (prefix != "e") return await parse.pack(fs.readFileSync(filepath), mId);
		} catch (e) {
			console.log(e);
			return null;
		}
	},
	loadXml(movieId) {
		return new Promise(async (res, rej) => {
			const i = movieId.indexOf("-");
			const prefix = movieId.substr(0, i);
			const suffix = movieId.substr(i + 1);
			switch (prefix) {
				case "m": {
					const fn = fUtil.getFileIndex("movie-", ".xml", suffix);
					if (fs.existsSync(fn)) res(fs.readFileSync(fn));
					else rej();
					break;
				} case "s": {
					const fn = fUtil.getFileIndex("starter-", ".xml", suffix);
					if (fs.existsSync(fn)) res(fs.readFileSync(fn));
					else rej();
					break;
				}
				case "e": {
					const filepath = `${exFolder}/${suffix}.zip`;
					if (!fs.existsSync(fn)) rej();
					const fn = fs.readFileSync(filepath);
					parse.unpackMutiple(fn).then((v) => res(v)).catch((e) => rej(e));
					break;
				}
				default:
					rej();
			}
		});
	},
	loadThumb(movieId) {
		return new Promise(async (res, rej) => {
			try {
				if (!movieId.startsWith("m-") && !movieId.startsWith("s-")) return;
				const n = Number.parseInt(movieId.substr(2));
				var fn;
				if (movieId.startsWith("m-")) fn = fUtil.getFileIndex("thumb-", ".png", n);
				else if (movieId.startsWith("s-")) fn = fUtil.getFileIndex("starter-", ".png", n);
				res(fs.readFileSync(fn));
			} catch (e) {
				rej(e);
			}
		});
	},
	list() {
		const array = [];
		const last = fUtil.getLastFileIndex("movie-", ".xml");
		for (let c = last; c >= 0; c--) {
			const movie = fs.existsSync(fUtil.getFileIndex("movie-", ".xml", c));
			const thumb = fs.existsSync(fUtil.getFileIndex("thumb-", ".png", c));
			if (movie && thumb) array.push(`m-${c}`);
		}
		return array;
	},
	listEx() {
		const table = [];
		fs.readdirSync(exFolder).forEach(file => {
			const id = file.split(".")[0];
			table.push(`e-${id}`);
		});
		return table;;
	},
	starters() {
		createMetaFolders("starter")
		const table = [];
		const ids = fUtil.getValidFileIndicies("starter-", ".xml");
		for (const i of ids) {
			const movie = fs.existsSync(fUtil.getFileIndex("starter-", ".xml", ids[i]));
			const thumb = fs.existsSync(fUtil.getFileIndex("starter-", ".png", ids[i]));
			if (movie && thumb) {
				const title = fs.readFileSync(`./meta/starter/titles/s-${ids[i]}.txt`, 'utf8');
				const tags = fs.readFileSync(`./meta/starter/tags/s-${ids[i]}.txt`, 'utf8');
				table.push({id: `s-${ids[i]}`, name: title, tag: tags});
			}
		}
		return table;
	},
	meta(movieId) {
		return new Promise(async (res, rej) => {
			if (!movieId.startsWith("m-") && !movieId.startsWith("s-") && !movieId.startsWith("e-")) return;
			const n = movieId.split("-")[1];
			var fn;
			if (movieId.startsWith("m-")) fn = fUtil.getFileIndex("movie-", ".xml", n);
			else if (movieId.startsWith("s-")) fn = fUtil.getFileIndex("starter-", ".xml", n);
			else if (movieId.startsWith("e-")) {
				const filepath = `${exFolder}/${n}.zip`;
				if (!fs.existsSync(filepath)) rej();
				const fp = fs.readFileSync(filepath);
				parse.unpackMutiple(fp).then((v) => {
					const b = v.xmlBuffer;

					var begTitle, endTitle; 
					if (b.includes("<title><![CDATA[")) {
						begTitle = b.indexOf("<title>") + 16;
						endTitle = b.indexOf("]]></title>");
					} else {
						begTitle = b.indexOf("<title>") + 7;
						endTitle = b.indexOf("</title>");
					}	
					const title = b.slice(begTitle, endTitle).toString().trim();
					const begDuration = b.indexOf('duration="') + 10;
					const endDuration = b.indexOf('"', begDuration);
					const duration = Number.parseFloat(b.slice(begDuration, endDuration));
					const min = ("" + ~~(duration / 60)).padStart(2, "0");
					const sec = ("" + ~~(duration % 60)).padStart(2, "0");
					const durationStr = `${min}:${sec}`;
					res({
						date: fs.statSync(filepath).mtime,
						durationString: durationStr,
						duration,
						title: title,
						id: movieId,
					});
				}).catch((e) => rej(e));
				return;
			}
			const fd = fs.openSync(fn, "r");
			const buffer = Buffer.alloc(256);
			fs.readSync(fd, buffer, 0, 256, 0);
			const begTitle = buffer.indexOf("<title>") + 16;
			const endTitle = buffer.indexOf("]]></title>");
			const title = buffer.slice(begTitle, endTitle).toString().trim();
			const begTag = buffer.indexOf("<tag>") + 14;
			const endTag = buffer.indexOf("]]></tag>");
			const tag = buffer.slice(begTag, endTag).toString().trim();
			const begDuration = buffer.indexOf('duration="') + 10;
			const endDuration = buffer.indexOf('"', begDuration);
			const duration = Number.parseFloat(buffer.slice(begDuration, endDuration));
			const min = ("" + ~~(duration / 60)).padStart(2, "0");
			const sec = ("" + ~~(duration % 60)).padStart(2, "0");
			const durationStr = `${min}:${sec}`;

			fs.closeSync(fd);
			res({
				date: fs.statSync(fn).mtime,
				durationString: durationStr,
				duration,
				title: title || "Untitled",
				id: movieId,
				tag
			});
		});
	},
	metaWithoutPromise(movieId) {
		if (!movieId.startsWith("m-") && !movieId.startsWith("s-")) return;
		const n = Number.parseInt(movieId.substr(2));
		var fn;
		if (movieId.startsWith("m-")) fn = fUtil.getFileIndex("movie-", ".xml", n);
		else if (movieId.startsWith("s-")) fn = fUtil.getFileIndex("starter-", ".xml", n);
		const fd = fs.openSync(fn, "r");
		const buffer = Buffer.alloc(256);
		fs.readSync(fd, buffer, 0, 256, 0);
		const begTitle = buffer.indexOf("<title>") + 16;
		const endTitle = buffer.indexOf("]]></title>");
		const title = buffer.slice(begTitle, endTitle).toString().trim();
		const begTag = buffer.indexOf("<tag>") + 14;
		const endTag = buffer.indexOf("]]></tag>");
		const tag = buffer.slice(begTag, endTag).toString().trim();
		const begDuration = buffer.indexOf('duration="') + 10;
		const endDuration = buffer.indexOf('"', begDuration);
		const duration = Number.parseFloat(buffer.slice(begDuration, endDuration));
		const min = ("" + ~~(duration / 60)).padStart(2, "0");
		const sec = ("" + ~~(duration % 60)).padStart(2, "0");
		const durationStr = `${min}:${sec}`;

		fs.closeSync(fd);
		return {
			date: fs.statSync(fn).mtime,
			durationString: durationStr,
			duration,
			title: title || "Untitled",
			id: movieId,
			tag
		};
	},
};
