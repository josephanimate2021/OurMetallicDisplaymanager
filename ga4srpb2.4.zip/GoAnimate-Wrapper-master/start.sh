echo Starting GoAnimate For Schools Remastered
npm start