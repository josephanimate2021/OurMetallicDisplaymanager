const voices = require("./info").voices;
const qs = require("querystring");
const https = require("https");
const md5 = require("js-md5");
const http = require("http");
const {convertToMp3} = require("../misc/file");

// Fallback option for compatibility between Wrapper and https://github.com/Windows81/Text2Speech-Haxxor-JS.
let get;
try {
	get = require("../misc/get");
} catch {
	get = require("./get");
}

module.exports = (voiceName, text) => {
	return new Promise(async (res, rej) => {
		const voice = voices[voiceName];
		switch (voice.source) {
			case "polly": {
				const body = new URLSearchParams({
					msg: text,
					lang: voice.arg,
					source: "ttsmp3"
				}).toString();

				const req = https.request(
					{
						hostname: "ttsmp3.com",
						path: "/makemp3_new.php",
						method: "POST",
						headers: { 
							"Content-Length": body.length,
							"Content-type": "application/x-www-form-urlencoded"
						}
					},
					(r) => {
						let body = "";
						r.on("data", (c) => body += c);
						r.on("end", () => {
							const json = JSON.parse(body);
							if (json.Error == 1) {
								return rej(json.Text);
							}

							https
								.get(json.URL, (r) => {
									const buffers = [];
									r.on("data", (b) => buffers.push(b)).on("end", () => res(Buffer.concat(buffers))).on("error", rej);;
								}).on("error", rej);
						});
						r.on("error", rej);
					}
				)
				req.on("error", rej);
				req.end(body);
				break;
			}
			case "cepstral": {
				https.get("https://www.cepstral.com/en/demos", async (r) => {
					const cookie = r.headers["set-cookie"];
					const q = new URLSearchParams({
						voiceText: text,
						voice: voice.arg,
					}).toString();

					https.get(
						{
							hostname: "www.cepstral.com",
							path: `/demos/createAudio.php?${q}`,
							headers: { Cookie: cookie }
						},
						(r) => {
							let body = "";
							r.on("data", (b) => body += b);
							r.on("end", () => {
								const json = JSON.parse(body);

								https
									.get(`https://www.cepstral.com${json.mp3_loc}`, (r) => {
										const buffers = [];
										r.on("data", (b) => buffers.push(b)).on("end", () => res(Buffer.concat(buffers))).on("error", rej);;
									}).on("error", rej);
							});
							r.on("error", rej);
						}
					).on("error", rej);
				}).on("error", rej);
				break;
			}

			case "voiceforge": {
				const q = new URLSearchParams({						
					msg: text,
					voice: voice.arg,
					email: "null"
				}).toString();
				
				https.get({
					hostname: "api.voiceforge.com",
					path: `/swift_engine?${q}`,
					headers: { 
						"User-Agent": "just_audio/2.7.0 (Linux;Android 11) ExoPlayerLib/2.15.0",
						"HTTP_X_API_KEY": "8b3f76a8539",
						"Accept-Encoding": "identity",
						"Icy-Metadata": "1",
					}
				}, (r) => convertToMp3(r, "wav").then((v) => {
					const buffers = [];
					v.on("data", (b) => buffers.push(b)).on("end", () => res(Buffer.concat(buffers))).on("error", rej);;
				}).catch(rej)).on("error", rej);
				break;
			}
			case "vocalware": {
				var [eid, lid, vid] = voice.arg;
				var cs = md5(`${eid}${lid}${vid}${text}1mp35883747uetivb9tb8108wfj`);
				var q = qs.encode({
					EID: voice.arg[0],
					LID: voice.arg[1],
					VID: voice.arg[2],
					TXT: text,
					EXT: "mp3",
					IS_UTF8: 1,
					ACC: 5883747,
					cache_flag: 3,
					CS: cs,
				});
				https.get(
					{
						host: "cache-a.oddcast.com",
						path: `/tts/gen.php?${q}`,
						headers: {
							Referer: "https://www.oddcast.com/",
							Origin: "https://www.oddcast.com/",
							"User-Agent":
								"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36",
						},
					},
					(r) => {
						var buffers = [];
						r.on("data", (d) => buffers.push(d));
						r.on("end", () => res(Buffer.concat(buffers)));
						r.on("error", rej);
					}
				);
				break;
			}
			case "acapela": {
				let acapelaArray = [];
				for (let c = 0; c < 15; c++) acapelaArray.push(~~(65 + Math.random() * 26));
				const email = `${String.fromCharCode.apply(null, acapelaArray)}@gmail.com`;

				let req = https.request(
					{
						hostname: "acapelavoices.acapela-group.com",
						path: "/index/getnonce",
						method: "POST",
						headers: {
							"Content-Type": "application/x-www-form-urlencoded",
						},
					},
					(r) => {
						let buffers = [];
						r.on("data", (b) => buffers.push(b));
						r.on("end", () => {
							const nonce = JSON.parse(Buffer.concat(buffers)).nonce;
							let req = https.request(
								{
									hostname: "acapela-group.com",
									port: "8443",
									path: "/Services/Synthesizer",
									method: "POST",
									headers: {
										"Content-Type": "application/x-www-form-urlencoded",
									},
								},
								(r) => {
									let buffers = [];
									r.on("data", (d) => buffers.push(d));
									r.on("end", () => {
										const html = Buffer.concat(buffers);
										const beg = html.indexOf("&snd_url=") + 9;
										const end = html.indexOf("&", beg);
										const sub = html.subarray(beg, end).toString();

										https
											.get(sub, (r) => {
												const buffers = [];
												r.on("data", (b) => buffers.push(b)).on("end", () => res(Buffer.concat(buffers))).on("error", rej);;
											}).on("error", rej);
									});
									r.on("error", rej);
								}
							).on("error", rej);
							req.end(
								new URLSearchParams({
									req_voice: voice.arg,
									cl_pwd: "",
									cl_vers: "1-30",
									req_echo: "ON",
									cl_login: "AcapelaGroup",
									req_comment: `{"nonce":"${nonce}","user":"${email}"}`,
									req_text: text,
									cl_env: "ACAPELA_VOICES",
									prot_vers: 2,
									cl_app: "AcapelaGroup_WebDemo_Android",
								}).toString()
							);
						});
					}
				).on("error", rej);
				req.end(
					new URLSearchParams({
						json: `{"googleid":"${email}"`,
					}).toString()
				);
				break;
			}
			case "readloud": {
				const req = https.request(
					{
						hostname: "101.99.94.14",														
						path: voice.arg,
						method: "POST",
						headers: { 			
							Host: "gonutts.net",					
							"Content-Type": "application/x-www-form-urlencoded"
						}
					},
					(r) => {
						let buffers = [];
						r.on("data", (b) => buffers.push(b));
						r.on("end", () => {
							const html = Buffer.concat(buffers);
							const beg = html.indexOf("/tmp/");
							const end = html.indexOf("mp3", beg) + 3;
							const path = html.subarray(beg, end).toString();

							if (path.length > 0) {
								https.get({
									hostname: "101.99.94.14",	
									path: `/${path}`,
									headers: {
										Host: "gonutts.net"
									}
								}, (r) => {
									const buffers = [];
									r.on("data", (b) => buffers.push(b)).on("end", () => res(Buffer.concat(buffers))).on("error", rej);;
								}).on("error", rej);
							} else {
								return rej("Could not find voice clip file in response.");
							}
						});
					}
				);
				req.on("error", rej);
				req.end(
					new URLSearchParams({
						but1: text,
						butS: 0,
						butP: 0,
						butPauses: 0,
						but: "Submit",
					}).toString()
				);
				break;
			}
		}
	});
};
