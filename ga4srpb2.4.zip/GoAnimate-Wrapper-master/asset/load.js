const loadPost = require("../misc/post_body");
const asset = require("./main");
const nodezip = require("node-zip");
const fUtil = require("../misc/file");
const http = require("http");
const fs = require("fs");
const base = Buffer.alloc(1, 0);

/**
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 * @param {import("url").UrlWithParsedQuery} url
 * @returns {boolean}
 */
module.exports = function (req, res, url) {
	var currentId = false;
	switch (req.method) {
		case "GET": {
			switch (url.pathname) {
				case "/ajax/getVideoCount": currentId = true;
				case "/ajax/getNewMovieId": { // designed for example movie ids.
					if (!currentId) {
						const presaveId = `e-${fUtil.generateId()}`;
						if (url.query.hasId) res.end(JSON.stringify({mId: url.query.id}));
						else res.end(JSON.stringify({mId: presaveId}));
					} else res.end(`m-${fUtil.getNextFileId("movie-", ".xml")}`);
					break;
				}
			}
			const match = req.url.match(/\/assets\/([^/]+)$/);
			if (!match) return;
			const aId = match[1];
			const subtype = aId.split("-")[1].split(".")[0];
			var folder;
			if (subtype == "watermark") folder = `./watermarks`;
			else folder = `./${subtype}`;
			res.end(fs.readFileSync(`${folder}/${aId}`));
			return true;
		}
	}
};
