echo Installing Node.js...
# removes all old node.js stuff before doing a manual node.js installation for all linux distros including GalliumOS.
sudo add-apt-repository -y -r ppa:chris-lea/node.js &&\
sudo rm -f /etc/apt/sources.list.d/chris-lea-node_js-*.list &&\
sudo rm -f /etc/apt/sources.list.d/chris-lea-node_js-*.list.save
# adds a nodesource package signing key
KEYRING=/usr/share/keyrings/nodesource.gpg
curl -fsSL https://deb.nodesource.com/gpgkey/nodesource.gpg.key | gpg --dearmor | sudo tee "$KEYRING" >/dev/null
gpg --no-default-keyring --keyring "$KEYRING" --list-keys
chmod a+r /usr/share/keyrings/nodesource.gpg
# adds a nodesource repo
VERSION=node_16.x
DISTRO="$(lsb_release -s -c)"
echo "deb [signed-by=$KEYRING] https://deb.nodesource.com/$VERSION $DISTRO main" | sudo tee /etc/apt/sources.list.d/nodesource.list
echo "deb-src [signed-by=$KEYRING] https://deb.nodesource.com/$VERSION $DISTRO main" | sudo tee -a /etc/apt/sources.list.d/nodesource.list
# installs node.js
sudo apt-get update
sudo apt-get install nodejs
echo Node.js is installed. now installing dependecies
npm install
echo All of the dependecies are now installed. You may now close this window.
timeout 9999
