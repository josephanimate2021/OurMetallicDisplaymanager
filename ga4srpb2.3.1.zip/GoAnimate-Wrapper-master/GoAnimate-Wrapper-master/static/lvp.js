const http = require("http");

/**
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 * @param {import("url").UrlWithParsedQuery} url
 * @returns {boolean}
 */
module.exports = function (req, res, url) {
	var path = url.pathname;
	if (req.method != "POST" || !path.startsWith("/movie")) return;
	res.statusCode = 302;
	res.setHeader("Location", `/movie/${path.substr(path.lastIndexOf("/") + 1)}`);
	res.end();
	return true;
};