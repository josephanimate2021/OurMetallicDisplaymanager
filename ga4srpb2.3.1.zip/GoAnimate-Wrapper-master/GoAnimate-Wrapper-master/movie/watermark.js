const fs = require("fs");
const asset = require("../asset/main");
const loadPost = require('../misc/post_body');
const fUtil = require("../misc/file");
const caché = require("../asset/caché");
function createIdFolders(id) {
	try {
		const dirs = ['./meta', `./meta/${id}`];
		for (const dir of dirs) {
			if (!fs.existsSync(dir)) fs.mkdirSync(dir);
		}
	} catch (e) {
        console.log(e);
	}
    return true;
}
module.exports = function (req, res, url) {
	switch (req.method) {
        case "POST": {
            switch (url.pathname) {
                case "/ajax/watermark/use": {
                    loadPost(req, res).then(([data]) => {
                        try {
                            const id = data.id;
                            if (data.use_watermark) fs.writeFileSync(`./meta/watermark/default.txt`, `<watermarks><watermark>/assets/${id}</watermark></watermarks>`);
                            else if (data.delete_watermark) fs.unlinkSync(`./meta/watermark/default.txt`);
                            res.end(JSON.stringify({status: "ok"}));
                        } catch (e) {
                            console.log(e);
                            res.end(JSON.stringify({status: "error"}));
                        }
                    });
                    break;
                } case "/ajax/watermarks/list": {
                    fs.readdirSync('./meta/watermark').forEach(file => {
                        if (file != "default.txt") return;
                        res.end(JSON.stringify({xml: fs.readFileSync(`./meta/watermark/${file}`, 'utf8')}));
                    })
                    break;
                } case "/ajax/watermark/delete": {
                    loadPost(req, res).then(([data]) => {
                        try {
                            const id = data.id;
                            fs.unlinkSync(`./watermarks/${id}`);
                            fs.unlinkSync(`./meta/watermark/titles/${id.split("-")[0]}-watermark.txt`);
                            res.end(JSON.stringify({status: "ok"}));
                        } catch (e) {
                            console.log(e);
                            res.end(JSON.stringify({status: "error"}));
                        }
                    });
                    break;
                } case "/ajax/movie/delete":
                case "/goapi/deleteUserTemplate/": {
                    loadPost(req, res).then(([data]) => {
                        try {
                            const mId = data.mId || data.templateId;
                            var filepath, thumbpath;
                            const [ prefix, suffix ] = mId.split("-");
                            switch (prefix) {
                                case "m": {
                                    filepath = fUtil.getFileIndex("movie-", ".xml", suffix);
                                    thumbpath = fUtil.getFileIndex("thumb-", ".png", suffix);
                                    fs.unlinkSync(`./meta/${mId}/watermark.txt`);
                                    caché.clearTable(mId, false);
                                    fs.unlinkSync(thumbpath);
                                    break;
                                } case "e": {
                                    filepath = `${process.env.EXAMPLE_FOLDER}/${suffix}.zip`;
                                    caché.clearTable(mId, false);
                                    break;
                                } case "s": {
                                    filepath = fUtil.getFileIndex("starter-", ".xml", suffix);
                                    thumbpath = fUtil.getFileIndex("starter-", ".png", suffix);
                                    fs.unlinkSync(thumbpath);
                                    fs.unlinkSync(`./meta/starter/titles/${mId}.txt`);
                                    fs.unlinkSync(`./meta/starter/tags/${mId}.txt`);
                                    break;
                                }
                            }
                            fs.unlinkSync(filepath);
                            if (data.mId) res.end(JSON.stringify({status: "ok"}));
                            else res.end("1");
                        } catch (e) {
                            console.log(e);
                            if (data.mId) res.end(JSON.stringify({status: "error"}));
                        }
                    })
                }
            }
            if (!url.pathname.startsWith("/goapi/assignwatermark/")) return;
            const pieces = url.pathname.split("/");
            const mId = pieces[4];
            const wId = pieces[5];
            var text;
            switch (wId) {
                case "0vTLbQy9hG7k": {
                    text = "";
                    break;
                } case "0dhteqDBt5nY": {
                    text = '<watermarks><watermark style="bluepeacocks"/></watermarks>'
                    break;
                } default: {
                    text = `<watermarks><watermark>/assets/${wId}</watermark></watermarks>`;
                    break;
                }
            }
            if (createIdFolders(mId)) fs.writeFileSync(`./meta/${mId}/watermark.txt`, text);
            break;
        } case "GET": {
            if (url.pathname != "/ajax/watermarks/list") return;
            res.end(JSON.stringify(asset.list("watermarks")));
            break;
        }
    }
    return true
};