const env = Object.assign(process.env, require("./env"), require("./config"));

const http = require("http");
const chr = require("./character/redirect");
const pmc = require("./character/premade");
const chl = require("./character/load");
const cht = require("./character/thmb");
const skl = require("./static/school");
const mvu = require("./movie/upload");
const stl = require("./static/load");
const stp = require("./static/page");
const scc = require("./static/pagecc");
const lvp = require("./static/pagelvp");
const wtr = require("./movie/watermark");
const svp = require("./static/lvp");
const asl = require("./asset/load");
const ast = require("./asset/thmb");
const mvl = require("./movie/load");
const mvL = require("./movie/list");
const mvX = require("./movie/listEx");
const mvm = require("./movie/meta");
const mvt = require("./movie/thmb");
const thl = require("./theme/load");
const stc = require("./static.js");
const url = require("url");

const functions = [mvL, scc, mvX, svp, skl, wtr, pmc, stc, lvp, asl, chl, thl, cht, chr, ast, mvm, mvl, mvt, mvu, stp, stl];

module.exports = http
	.createServer((req, res) => {
		try {
			const parsedUrl = url.parse(req.url, true);
			//if (!parsedUrl.path.endsWith('/')) parsedUrl.path += '/';
			const found = functions.find((f) => f(req, res, parsedUrl));
			console.log(req.method, parsedUrl.path);
			if (!found) {
				res.statusCode = 404;
				res.end();
			}
		} catch (x) {
			res.statusCode = 404;
			res.end();
		}
	})
	.listen(env.PORT || env.SERVER_PORT, console.log);
